using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace MM2.AI
{
    sealed class LaneSlot
    {
        public Lane Lane;
        public float Occupied;
        public float Max;
        public bool Full;
        public float NextFront;
    }

    // / <summary>
    // / Structure containing the basic data needed to position an entity on a road
    // / </summary>
    public struct RoadPositioningInfo
    {
        public RoadInstance RoadInstance;
        public RoadSide SideOfRoad;
        public int RailIndex;
        public int Relation; // used for e.g. relation to the next/prev road
        public RoadData RoadData => RoadInstance == null ? null : (SideOfRoad > 0 ? RoadInstance.Road.RightData : RoadInstance.Road.LeftData);

        public static RoadPositioningInfo Null => new RoadPositioningInfo() { RoadInstance = null };
    }

    public class AINetwork : MonoBehaviour
    {
        public SDLCity Level => level;
        private SDLCity level;

        public AINetworkData Data => networkData;
        private AINetworkData networkData;

        [Header("Gizmos")]
        [SerializeField] private bool drawEntityGizmos = true;
        [SerializeField] private Color trafficGizmoColor = new Color(0f, 0.6f, 1f, 0.35f);
        [SerializeField] private Color pedestrianGizmoColor = new Color(1f, 0.8f, 0f, 0.35f);
        [SerializeField] private Color proxyGizmoColor = new Color(1.0f, 0.0f, 0.0f, 0.35f);
        [SerializeField] private Color forwardGizmoColor = Color.green;

        // ai dvehicle data holder
        public AIVehicleDataManager VehicleDataManager => vehicleDataManager;
        private AIVehicleDataManager vehicleDataManager = new AIVehicleDataManager();

        // sim data
        public IReadOnlyList<RoadInstance> Roads => roads;
        public IReadOnlyList<IntersectionInstance> Intersections => intersections;

        private readonly List<RoadInstance> roads = new List<RoadInstance>();
        private readonly List<IntersectionInstance> intersections = new List<IntersectionInstance>();

        // maps
        public Dictionary<int, List<int>> RoomRoadMap = new Dictionary<int, List<int>>();
        public Dictionary<int, int> RoomIntersectionMap = new Dictionary<int, int>();
        public Dictionary<Vector3, int> IntersectionPosMap = new Dictionary<Vector3, int>();

        public List<AIVehicleProxy> VehicleProxies = new List<AIVehicleProxy>();

        // statics
        public static bool DrawActiveCullroomBound = true;
        public static bool DrawCapacityDebug = false;

        // pools
        private AITrafficCar[] TrafficCarPool;
        private AIPedestrian[] PedestrianPool;
        private int activeTrafficCarCount = 0;
        private int activePedCount = 0;

        // repositioining data
        private const float SpawnMinGap = 3f;    
        private const float SpawnRandomGap = 8f;
        private const float PedSpawnMinGap = 0.5f;
        private const float PedSpawnRandomGap = 3f;
        private readonly List<LaneSlot> laneSlots = new List<LaneSlot>();

        // repositioning
        private static float OccupiedLength(Lane lane)
        {
            float total = 0f;
            for (int i = 0; i < lane.Ordered.Count; i++)
            {
                var e = lane.Ordered[i];
                total += e.FrontBumperDistance - e.RearBumperDistance;
            }
            return total;
        }

        /// Where the next entity's front should go: the lane's exit end, or behind the rearmost entity.
        private static float GetInitialNextFront(Lane lane, float minGap)
        {
            int dir = lane.Direction;
            float roadLength = lane.Instance.Road.Length;

            if (lane.Count == 0)
                return (dir > 0 ? roadLength : 0f) - minGap * dir;

            var rearmost = dir > 0 ? lane.Ordered[0] : lane.Ordered[lane.Count - 1];
            float theirRear = rearmost.CurrentPathDistance + rearmost.RearBumperDistance * dir;
            return theirRear - minGap * dir;
        }

        /// Places the entity at the back of the slot's queue. Returns false if it doesn't fit.
        private static bool TryPlaceInSlot(AIRailEntity entity, LaneSlot slot, float minGap, float randomGap)
        {
            var lane = slot.Lane;
            int dir = lane.Direction;
            float roadLength = lane.Instance.Road.Length;
            float entryEnd = dir > 0 ? 0f : roadLength;

            float originDist = slot.NextFront - entity.FrontBumperDistance * dir;
            float rearDist = originDist + entity.RearBumperDistance * dir;

            // Ran past the lane's entry end.
            if ((rearDist - entryEnd) * dir < 0f)
                return false;

            // Progress before SetRoad: Lane.Insert sorts on it.
            entity.NormalizedPathProgress = originDist / roadLength;
            entity.SetRoad(new RoadPositioningInfo
            {
                RoadInstance = lane.Instance,
                SideOfRoad = lane.Side,
                RailIndex = lane.RailIndex
            });
            entity.PositionAlongPath(entity.NormalizedPathProgress);

            slot.NextFront = rearDist - (minGap + UnityEngine.Random.value * randomGap) * dir;
            return true;
        }

        private void RepositionPedestrians()
        {
            var cullRoads = networkData.PedestrianCullRoads[activeCullingRoom - 1];
            var roomCenter = level.GetRoom(activeCullingRoom).Bounds.center.ToVec2XZ();
            var roadIdsDistanceDec = cullRoads
                .OrderByDescending(x => (networkData.Roads[x].GetCenter().ToVec2XZ() - roomCenter).sqrMagnitude)
                .ToList();

            // Flatten every pedestrian lane on every candidate road, farthest road first.
            laneSlots.Clear();
            foreach (var roadId in roadIdsDistanceDec)
            {
                var road = Roads[roadId];
                float maxLengthOccupation = road.Road.Length / 16f;

                for (int s = 0; s < 2; s++)
                {
                    var lanes = road.GetLanes((RoadSide)s, RailType.Pedestrian);
                    for (int i = 0; i < lanes.Count; i++)
                    {
                        var lane = lanes[i];
                        laneSlots.Add(new LaneSlot
                        {
                            Lane = lane,
                            Occupied = OccupiedLength(lane),
                            Max = maxLengthOccupation,
                            NextFront = GetInitialNextFront(lane, PedSpawnMinGap)
                        });
                    }
                }
            }

            // One ped per lane per pass, until the peds run out or every lane is full.
            int cursor = 0;
            bool placedAny = true;
            while (placedAny)
            {
                placedAny = false;
                for (int s = 0; s < laneSlots.Count; s++)
                {
                    var slot = laneSlots[s];
                    if (slot.Full) continue;

                    // advance to the next ped that actually needs relocating
                    while (cursor < PedestrianPool.Length &&
                           (PedestrianPool[cursor] == null || EntityWithinCullBubble(PedestrianPool[cursor])))
                        cursor++;
                    if (cursor >= PedestrianPool.Length) return;

                    var ped = PedestrianPool[cursor];
                    float pedLength = ped.FrontBumperDistance - ped.RearBumperDistance;
                    if (slot.Occupied + pedLength > slot.Max) { slot.Full = true; continue; }

                    if (!TryPlaceInSlot(ped, slot, PedSpawnMinGap, PedSpawnRandomGap)) { slot.Full = true; continue; }

                    slot.Occupied += pedLength;
                    cursor++;
                    placedAny = true;
                }
            }

            // any unaccounted for peds get set inactive
            for (int i = cursor; i < PedestrianPool.Length; i++)
            {
                var ped = PedestrianPool[i];
                if (ped != null && !EntityWithinCullBubble(ped))
                {
                    Debug.LogWarning("Failed to reposition a ped that is outside the current culling area. Deactivating this ped.");
                }
            }
        }

        private void RepositionTraffic()
        {
            var cullRoads = networkData.CombinedCullRoads[activeCullingRoom - 1];
            var roomCenter = level.GetRoom(activeCullingRoom).Bounds.center.ToVec2XZ();
            var roadIdsDistanceDec = cullRoads
                .OrderByDescending(x => (networkData.Roads[x].GetCenter().ToVec2XZ() - roomCenter).sqrMagnitude)
                .ToList();

            // Roads already held by a proxy vehicle are off limits.
            if (VehicleProxies.Count > 0)
            {
                var forbiddenIds = new HashSet<int>();
                foreach (var proxy in VehicleProxies)
                {
                    if (proxy.RoadInfo.RoadInstance == null) continue;
                    forbiddenIds.Add(proxy.RoadInfo.RoadInstance.Id);
                }
                roadIdsDistanceDec.RemoveAll(x => forbiddenIds.Contains(x));
            }

            // Flatten every vehicle lane on every candidate road, farthest road first.
            laneSlots.Clear();
            foreach (var roadId in roadIdsDistanceDec)
            {
                var road = Roads[roadId];
                float maxLengthOccupation = road.Road.Length / 4f;

                for (int s = 0; s < 2; s++)
                {
                    var lanes = road.GetLanes((RoadSide)s, RailType.Vehicle);
                    for (int i = 0; i < lanes.Count; i++)
                    {
                        var lane = lanes[i];
                        laneSlots.Add(new LaneSlot
                        {
                            Lane = lane,
                            Occupied = OccupiedLength(lane),
                            Max = maxLengthOccupation,
                            NextFront = GetInitialNextFront(lane, SpawnMinGap)
                        });
                    }
                }
            }

            // One car per lane per pass, until the cars run out or every lane is full.
            int cursor = 0;
            bool placedAny = true;
            while (placedAny)
            {
                placedAny = false;
                for (int s = 0; s < laneSlots.Count; s++)
                {
                    var slot = laneSlots[s];
                    if (slot.Full) continue;

                    // advance to the next car that actually needs relocating
                    while (cursor < TrafficCarPool.Length &&
                           (TrafficCarPool[cursor] == null || EntityWithinCullBubble(TrafficCarPool[cursor])))
                        cursor++;
                    if (cursor >= TrafficCarPool.Length) return;

                    var car = TrafficCarPool[cursor];
                    float carLength = car.FrontBumperDistance - car.RearBumperDistance;
                    if (slot.Occupied + carLength > slot.Max) { slot.Full = true; continue; }

                    if (!TryPlaceInSlot(car, slot, SpawnMinGap, SpawnRandomGap)) { slot.Full = true; continue; }

                    slot.Occupied += carLength;
                    cursor++;
                    placedAny = true;
                }
            }

            for (int i = cursor; i < TrafficCarPool.Length; i++)
            {
                var car = TrafficCarPool[i];
                if (car != null && !EntityWithinCullBubble(car))
                {
                    Debug.LogWarning("Failed to reposition a traffic car that is outside the current culling area. Deactivating this car.");
                }
            }
        }

        // culling
        private int activeCullingRoom = -1;

        public bool IntersectionWithinCulling(Intersection intersection, AmbientTypeFlags cullFlags)
        {
            foreach (var road in intersection.Roads)
            {
                if (RoadWithinCulling(road, cullFlags))
                    return true;
            }
            return false;
        }

        public bool IntersectionWithinCulling(int intersectionId, AmbientTypeFlags cullFlags)
        {
            return IntersectionWithinCulling(Intersections[intersectionId].Intersection, cullFlags);
        }

        public bool RoadWithinCulling(Road road, AmbientTypeFlags cullFlags)
        {
            return RoadWithinCulling(road.Id, cullFlags);
        }

        public bool RoadWithinCulling(int roadId, AmbientTypeFlags cullFlags)
        {
            if (activeCullingRoom <= 0)
            {
                // no cull room, everything hides
                return true;
            }

            var cullRoads = (cullFlags & AmbientTypeFlags.Vehicles) != 0 ? networkData.CombinedCullRoads[activeCullingRoom - 1]
                                                                         : networkData.PedestrianCullRoads[activeCullingRoom - 1];
            return cullRoads.Contains(roadId);
        }

        public bool RoadAtEdgeOfCullBubble(int roadID, AmbientTypeFlags cullFlags)
        {
            if (activeCullingRoom <= 0)
            {
                // no cull room, everything hides
                return true;
            }

            var road = networkData.Roads[roadID];
            var is1 = networkData.Intersections[road.RightEndData.IntersectionID];
            int is1count = 0;
            var is2 = networkData.Intersections[road.LeftEndData.IntersectionID];
            int is2count = 0;

            foreach (var rd in is1.Roads)
            {
                if (RoadWithinCulling(rd, cullFlags))
                    is1count++;
            }
            foreach (var rd in is2.Roads)
            {
                if (RoadWithinCulling(rd, cullFlags))
                    is2count++;
            }

            return is1count == 0 || is2count == 0;
        }

        public bool RoadAtEdgeOfCullBubble(Road road, AmbientTypeFlags cullFlags)
        {
            return RoadAtEdgeOfCullBubble(road.Id, cullFlags);
        }

        public bool EntityAtEdgeOfCullBubble(AIEntity entity)
        {
            var cullRoadLists = (entity is AITrafficCar) ? networkData.CombinedCullRoads : networkData.PedestrianCullRoads;
            if (activeCullingRoom <= 0)
                return false;

            // check if any roads at dest intersection are possible
            var cullRoads = cullRoadLists[activeCullingRoom - 1];
            int numAvailableRoads = 0;
            foreach (var endRoad in entity.CurrentDestIntersection.Intersection.Roads)
            {
                if (cullRoads.Contains(endRoad.Id))
                    numAvailableRoads++;
            }
            return numAvailableRoads == 0;
        }

        public bool EntityWithinCullBubble(AIEntity entity)
        {
            if (activeCullingRoom <= 0)
                return true;
            // Entities crossing an intersection have no current road; judge them by the road they're heading onto.
            var roadInstance = entity.RoadInfo.RoadInstance ?? entity.NextRoadInfo.RoadInstance;
            if (roadInstance == null)
                return false;

            var cullRoadLists = (entity.RailType != RailType.Pedestrian) ? networkData.CombinedCullRoads 
                                                                         : networkData.PedestrianCullRoads;

            // check if any roads at dest intersection are possible
            var cullRoads = cullRoadLists[activeCullingRoom-1];
            return cullRoads.Contains(roadInstance.Id);
        }

        public static void GetNextRoadInfo(RailType railType, Road road, int intersectionId, out RoadData data, out int railCount, out RoadSide sideNum)
        {
            railCount = -1;
            data = null;
            sideNum = RoadSide.Invalid;

            // special case for looping roads
            if (road.LeftEndData.IntersectionID == road.RightEndData.IntersectionID)
            {
                if (road.LeftData.GetRailCount(railType) > road.RightData.GetRailCount(railType))
                {
                    data = road.LeftData;
                    sideNum = RoadSide.Left;
                }
                else
                {
                    data = road.RightData;
                    sideNum = RoadSide.Right;
                }
            }
            else
            {
                data = (road.LeftEndData.IntersectionID == intersectionId) ? road.LeftData : road.RightData;
                sideNum = (road.LeftEndData.IntersectionID == intersectionId) ? RoadSide.Left : RoadSide.Right;
            }

            if (data != null)
                railCount = data.GetRailCount(railType);
        }

        public RoadPositioningInfo? DetermineNextFreewayRoad(AIEntity entity)
        {
            return DetermineNextFreewayRoad(entity.RoadInfo, entity.RailType, entity.AmbientTypeFlagMask);
        }

        public RoadPositioningInfo? DetermineNextFreewayRoad(RoadPositioningInfo sourceRoad, RailType railType, AmbientTypeFlags typeFlags)
        {
            var intersectionEnd = networkData.Intersections[sourceRoad.SideOfRoad == 0 ? sourceRoad.RoadInstance.Road.RightEndData.IntersectionID
                                                                                                     : sourceRoad.RoadInstance.Road.LeftEndData.IntersectionID];
            int roadIdx = intersectionEnd.Roads.IndexOf(sourceRoad.RoadInstance.Road);

            // take off ramp, or determine or next road like normal
            var offRampRoad = intersectionEnd.Roads[intersectionEnd.Roads.WrapIndex(roadIdx + 1)];
            var offRampSide = (offRampRoad.LeftEndData.IntersectionID == intersectionEnd.Id) ? offRampRoad.LeftData : offRampRoad.RightData;
            bool canTakeOffRamp = offRampSide.GetRailCount(railType) > 0 && (offRampSide.AiTypeFlags & typeFlags) > 0;

            bool shouldTakeOffRamp = (sourceRoad.RailIndex == sourceRoad.RoadData.numLanes - 1) && UnityEngine.Random.value > 0.5f;

            if (shouldTakeOffRamp && canTakeOffRamp)
            {
                // take the off ramp!
                return new RoadPositioningInfo
                {
                    RoadInstance = Roads[offRampRoad.Id],
                    RailIndex = 0,
                    SideOfRoad = (offRampRoad.RightEndData.IntersectionID == intersectionEnd.Id) ? RoadSide.Right : RoadSide.Left,
                    Relation = 1
                };
            }
            else
            {
                // try and go straight because off ramps might merge here
                if (intersectionEnd.Roads.Count == 4)
                {
                    Road forwardRoad = (intersectionEnd.Roads.Count == 4) ? intersectionEnd.Roads[intersectionEnd.Roads.WrapIndex(roadIdx - 2)]
                                                                           : GetRoadAhead(sourceRoad.RoadInstance.Road, intersectionEnd);
                    RoadData forwardRoadSide = null;
                    int forwardRoadRailCount = -1;
                    RoadSide forwardRoadSideId = RoadSide.Invalid;

                    if (forwardRoad != null)
                        GetNextRoadInfo(railType, forwardRoad, intersectionEnd.Id, out forwardRoadSide, out forwardRoadRailCount, out forwardRoadSideId);

                    bool canGoStraight = forwardRoad != null && (forwardRoadSide.AiTypeFlags & typeFlags) > 0 && forwardRoadRailCount > 0 && forwardRoad.Id != sourceRoad.RoadInstance.Id;

                    if (canGoStraight)
                    {
                        // going straight!
                        return new RoadPositioningInfo
                        {
                            RoadInstance = Roads[forwardRoad.Id],
                            SideOfRoad = forwardRoadSideId,
                            RailIndex = (sourceRoad.RailIndex <= forwardRoadRailCount - 1) ? sourceRoad.RailIndex : forwardRoadRailCount - 1,
                            Relation = 0
                        };
                    }
                    else
                    {
                        // otherwise find a new road
                        return DetermineNextNormalRoad(sourceRoad, railType, typeFlags);
                    }
                }
                else
                {
                    // otherwise find a new road
                    return DetermineNextNormalRoad(sourceRoad, railType, typeFlags);
                }
            }
        }

        public RoadPositioningInfo? DetermineNextNormalRoad(AIEntity entity)
        {
            return DetermineNextNormalRoad(entity.RoadInfo, entity.RailType, entity.AmbientTypeFlagMask);
        }

        public RoadPositioningInfo? DetermineNextNormalRoad(RoadPositioningInfo sourceRoad, RailType railType, AmbientTypeFlags typeFlags)
        {
            var intersectionEnd = networkData.Intersections[sourceRoad.SideOfRoad == 0 ? sourceRoad.RoadInstance.Road.RightEndData.IntersectionID
                                                                                                     : sourceRoad.RoadInstance.Road.LeftEndData.IntersectionID];
            var intersectionIndexInList = sourceRoad.SideOfRoad == 0 ? sourceRoad.RoadInstance.Road.RightEndData.IntersectionRoadIndex
                                                                      : sourceRoad.RoadInstance.Road.LeftEndData.IntersectionRoadIndex;
            int roadIdx = intersectionIndexInList < 32 ? intersectionIndexInList : intersectionEnd.Roads.IndexOf(sourceRoad.RoadInstance.Road);

            //  Rule: WTF, we're the only one!
            if (intersectionEnd.Roads.Count <= 1)
            {
                return null;
            }

            //  Rule: One rail 
            //  Try and choose next road randomly
            if (sourceRoad.RoadData.GetRailCount(railType) == 1)
            {
                int nextRoadIdx = -1;

                // see if we're on a freeway on ramp, and choose that if we can
                if (intersectionEnd.Roads.Count == 4)
                {
                    int rightIntersectionIndex = intersectionEnd.Roads.WrapIndex(roadIdx + 1);
                    var rightRoad = intersectionEnd.Roads[rightIntersectionIndex];
                    if ((rightRoad.Flags & PathFlags.Freeway) > 0) // freeway, pick me!
                    {
                        nextRoadIdx = rightIntersectionIndex;
                    }
                }

                // didn't find a freeway, choose randomly
                if (nextRoadIdx < 0)
                {
                    int startRoad = UnityEngine.Random.Range(0, intersectionEnd.Roads.Count);
                    for (int i = 0; i < intersectionEnd.Roads.Count; i++)
                    {
                        int startOffset = (i + startRoad) % intersectionEnd.Roads.Count;

                        // don't choose self
                        if (startOffset == roadIdx)
                            continue;

                        var road = intersectionEnd.Roads[startOffset];
                        var roadData = (road.RightEndData.IntersectionID == intersectionEnd.Id) ? road.RightData : road.LeftData;
                        bool isRoadValid = (roadData.AiTypeFlags & typeFlags) > 0 && roadData.GetRailCount(railType) > 0;

                        if (isRoadValid)
                        {
                            nextRoadIdx = startOffset;
                            break;
                        }
                    }
                }

                // here we go!
                if (nextRoadIdx < 0)
                    return null;

                var nextRoad = intersectionEnd.Roads[nextRoadIdx];

                // get info and checks stuff
                GetNextRoadInfo(railType, nextRoad, intersectionEnd.Id, out RoadData nextRoadSide, out int nextRoadRailCount, out RoadSide nextRoadSideId);

                var nextRoadInfo = new RoadPositioningInfo
                {
                    RoadInstance = Roads[nextRoad.Id],
                    SideOfRoad = nextRoadSideId
                };

                float angleToNext = intersectionEnd.RoadAngles[roadIdx][nextRoadIdx];
                if (angleToNext > 15f)
                {
                    nextRoadInfo.Relation = 1;
                    nextRoadInfo.RailIndex = nextRoadRailCount - 1;
                }
                else if (angleToNext < -15f)
                {
                    nextRoadInfo.Relation = -1;
                    nextRoadInfo.RailIndex = 0;
                }
                else
                {
                    nextRoadInfo.Relation = 0;
                    nextRoadInfo.RailIndex = 0;
                }

                return nextRoadInfo;
            }

            //  Rule: Pick one road from this intersection
            if (intersectionEnd.Roads.Count >= 3)
            {
                // BLA
                Road leftRoad = (intersectionEnd.Roads.Count == 4) ? intersectionEnd.Roads[intersectionEnd.Roads.WrapIndex(roadIdx - 1)]
                                                                   : GetRoadToLeft(sourceRoad.RoadInstance.Road, intersectionEnd);
                RoadData leftRoadSide = null;
                int leftRoadRailCount = -1;
                RoadSide leftRoadSideId = RoadSide.Invalid;

                if (leftRoad != null)
                    GetNextRoadInfo(railType, leftRoad, intersectionEnd.Id, out leftRoadSide, out leftRoadRailCount, out leftRoadSideId);

                Road rightRoad = (intersectionEnd.Roads.Count == 4) ? intersectionEnd.Roads[intersectionEnd.Roads.WrapIndex(roadIdx + 1)]
                                                                    : GetRoadToRight(sourceRoad.RoadInstance.Road, intersectionEnd);
                RoadData rightRoadSide = null;
                int rightRoadRailCount = -1;
                RoadSide rightRoadSideId = RoadSide.Invalid;

                if (rightRoad != null)
                    GetNextRoadInfo(railType, rightRoad, intersectionEnd.Id, out rightRoadSide, out rightRoadRailCount, out rightRoadSideId);

                Road forwardRoad = (intersectionEnd.Roads.Count == 4) ? intersectionEnd.Roads[intersectionEnd.Roads.WrapIndex(roadIdx - 2)]
                                                                      : GetRoadAhead(sourceRoad.RoadInstance.Road, intersectionEnd);
                RoadData forwardRoadSide = null;
                int forwardRoadRailCount = -1;
                RoadSide forwardRoadSideId = RoadSide.Invalid;

                if (forwardRoad != null)
                    GetNextRoadInfo(railType, forwardRoad, intersectionEnd.Id, out forwardRoadSide, out forwardRoadRailCount, out forwardRoadSideId);

                // check if the same road got referenced (e.g. if this is a circular road)
                if ((leftRoad != null && leftRoad == forwardRoad) || (rightRoad != null && rightRoad == forwardRoad))
                {
                    // if so, fix this up so it's a turn / forward if possible
                    if (leftRoad != null && leftRoad == forwardRoad)
                    {
                        leftRoad = null;
                    }
                    if (rightRoad != null && rightRoad == forwardRoad)
                    {
                        forwardRoad = null;
                    }
                }

                // check if we can go any direction
                bool canTurnLeft = leftRoad != null && sourceRoad.RailIndex == 0 && (leftRoadSide.AiTypeFlags & typeFlags) > 0 && leftRoadRailCount > 0 && leftRoad.Id != sourceRoad.RoadInstance.Id;
                bool canTurnRight = rightRoad != null && sourceRoad.RailIndex == sourceRoad.RoadData.GetRailCount(railType) - 1 && (rightRoadSide.AiTypeFlags & typeFlags) > 0 && rightRoadRailCount > 0 && rightRoad.Id != sourceRoad.RoadInstance.Id;
                bool canGoStraight = forwardRoad != null && (forwardRoadSide.AiTypeFlags & typeFlags) > 0 && forwardRoadRailCount > 0 && forwardRoad.Id != sourceRoad.RoadInstance.Id;

                // can't go anywhere! we'll do a couple extra checks just to make sure
                if (!canGoStraight && !canTurnLeft && !canTurnRight)
                {
                    bool canTurnRightFromAnyLane = rightRoad != null
                                                   && (rightRoadSide.AiTypeFlags & typeFlags) > 0
                                                   && rightRoadRailCount > 0
                                                   && rightRoad.Id != sourceRoad.RoadInstance.Id;
                    bool canTurnLeftFromAnyLane = leftRoad != null
                                                   && (leftRoadSide.AiTypeFlags & typeFlags) > 0
                                                   && leftRoadRailCount > 0
                                                   && leftRoad.Id != sourceRoad.RoadInstance.Id;

                    if (!canTurnLeftFromAnyLane && !canTurnRightFromAnyLane)
                    {
                        // Debug.LogError($"ERROR: Could not find a suitable road to turn to from road {sourceRoad.Id}, intersection {intersectionEnd.Id}!");
                        return null;
                    }

                    // edge case, 4 lane road merging onto 2 roads with 2 lanes on each side
                    int myRailCount = sourceRoad.RoadData.GetRailCount(railType);
                    if (leftRoadRailCount + rightRoadRailCount == myRailCount && canTurnRightFromAnyLane && canTurnLeftFromAnyLane)
                    {
                        bool goLeft = sourceRoad.RailIndex < (myRailCount / 2);
                        if (goLeft)
                        {
                            return new RoadPositioningInfo
                            {
                                RoadInstance = Roads[leftRoad.Id],
                                RailIndex = 0,
                                SideOfRoad = leftRoadSideId,
                                Relation = -1
                            };
                        }
                        else
                        {
                            return new RoadPositioningInfo
                            {
                                RoadInstance = Roads[rightRoad.Id],
                                RailIndex = Mathf.Clamp(sourceRoad.RailIndex - (myRailCount / 2), 0, myRailCount - 1),
                                SideOfRoad = rightRoadSideId,
                                Relation = 1
                            };
                        }
                    }
                    else
                    {
                        // just go somewhere then
                        if (canTurnRightFromAnyLane)
                        {
                            return new RoadPositioningInfo
                            {
                                RoadInstance = Roads[rightRoad.Id],
                                RailIndex = Mathf.Clamp(sourceRoad.RailIndex, 0, rightRoadRailCount - 1),
                                SideOfRoad = rightRoadSideId,
                                Relation = 1
                            };
                        }
                        else if (canTurnLeftFromAnyLane)
                        {
                            return new RoadPositioningInfo
                            {
                                RoadInstance = Roads[leftRoad.Id],
                                RailIndex = Mathf.Clamp(sourceRoad.RailIndex, 0, leftRoadRailCount - 1),
                                SideOfRoad = leftRoadSideId,
                                Relation = -1
                            };
                        }
                    }
                }
                else
                {
                    // in some cases, go straight instead of turn, even if we can turn
                    float noTurnChance = UnityEngine.Random.value;
                    if (canGoStraight && (canTurnLeft || canTurnRight))
                    {
                        if (noTurnChance > 0.7f)
                        {
                            canTurnLeft = false;
                            canTurnRight = false;
                        }
                    }

                    // 
                    if (canTurnRight) // right or straight 
                    {
                        return new RoadPositioningInfo
                        {
                            RoadInstance = Roads[rightRoad.Id],
                            RailIndex = rightRoadRailCount - 1,
                            SideOfRoad = rightRoadSideId,
                            Relation = 1
                        };
                    }
                    else if (canTurnLeft) // left or straight
                    {
                        return new RoadPositioningInfo
                        {
                            RoadInstance = Roads[leftRoad.Id],
                            RailIndex = 0,
                            SideOfRoad = leftRoadSideId,
                            Relation = -1
                        };
                    }
                    else if (canGoStraight) // straight
                    {
                        return new RoadPositioningInfo
                        {
                            RoadInstance = Roads[forwardRoad.Id],
                            RailIndex = Mathf.Clamp(sourceRoad.RailIndex, 0, forwardRoadRailCount - 1),
                            SideOfRoad = forwardRoadSideId,
                            Relation = 0
                        };
                    }
                }
            }
            else if (intersectionEnd.Roads.Count == 2)
            {
                // try pass through
                Road forwardRoad = intersectionEnd.Roads[intersectionEnd.Roads.WrapIndex(roadIdx + 1)];
                RoadData forwardRoadSide = null;
                int forwardRoadRailCount = -1;
                RoadSide forwardRoadSideId = RoadSide.Invalid;

                GetNextRoadInfo(railType, forwardRoad, intersectionEnd.Id, out forwardRoadSide, out forwardRoadRailCount, out forwardRoadSideId);

                bool canGoStraight = (forwardRoadSide.AiTypeFlags & typeFlags) > 0 && forwardRoadRailCount > 0 && forwardRoad.Id != sourceRoad.RoadInstance.Id;
                if (!canGoStraight)
                {
                    return null;
                }


                return new RoadPositioningInfo
                {
                    RoadInstance = Roads[forwardRoad.Id],
                    RailIndex = Mathf.Clamp(sourceRoad.RailIndex, 0, forwardRoadSide.GetRailCount(railType) - 1),
                    SideOfRoad = forwardRoadSideId,
                    Relation = 0
                };
            }

            // todo: find out how this can happen :/
            return null;
        }

        // generic
        public RoadPositioningInfo? DetermineNextRoad(RoadPositioningInfo sourceRoad, RailType railType, AmbientTypeFlags typeFlags)
        {
            // determine next road
            var road = sourceRoad.RoadInstance.Road;

            // dead end, nothing to go to
            int destId = sourceRoad.SideOfRoad == 0 ? road.RightEndData.IntersectionID : road.LeftEndData.IntersectionID;
            if (destId < 0 || destId >= networkData.Intersections.Count)
                return null;

            if ((road.Flags & PathFlags.Freeway) > 0)
            {
                // freeway logic
                return DetermineNextFreewayRoad(sourceRoad, railType, typeFlags);
            }
            else
            {
                // normal logic
                return DetermineNextNormalRoad(sourceRoad, railType, typeFlags);
            }
        }

        public RoadPositioningInfo? DetermineNextRoad(AIEntity entity)
        {
            return DetermineNextRoad(entity.RoadInfo, entity.RailType, entity.AmbientTypeFlagMask);
        }

        // cable car
        public RoadPositioningInfo? DetermineNextCableCarRoad(RoadPositioningInfo sourceRoad)
        {
            var road = sourceRoad.RoadInstance.Road;
            var intersectionEnd = networkData.Intersections[sourceRoad.SideOfRoad == 0 ? road.RightEndData.IntersectionID
                                                                                       : road.LeftEndData.IntersectionID];
            var intersectionIndexInList = sourceRoad.SideOfRoad == 0 ? road.RightEndData.IntersectionRoadIndex
                                                                      : road.LeftEndData.IntersectionRoadIndex;
            int roadIdx = intersectionIndexInList < 32 ? intersectionIndexInList : intersectionEnd.Roads.IndexOf(road);

            //  Rule: WTF, we're the only one!
            // Debug.Log($"DetermineNextCableCarRoad src {sourceRoad.Id}");
            if (intersectionEnd.Roads.Count <= 1)
            {
                // Debug.Log($"DetermineNextCableCarRoad <= 1 rd");
                return null;
            }

            //  Rule: Pick one road from this intersection
            if (intersectionEnd.Roads.Count >= 3)
            {
                // BLA
                Road leftRoad = (intersectionEnd.Roads.Count == 4) ? intersectionEnd.Roads[intersectionEnd.Roads.WrapIndex(roadIdx - 1)]
                                                                   : GetRoadToLeft(road, intersectionEnd);
                RoadData leftRoadSide = null;
                int leftRoadRailCount = -1;
                RoadSide leftRoadSideId = RoadSide.Invalid;

                if (leftRoad != null)
                    GetNextRoadInfo(RailType.Tram, leftRoad, intersectionEnd.Id, out leftRoadSide, out leftRoadRailCount, out leftRoadSideId);

                Road rightRoad = (intersectionEnd.Roads.Count == 4) ? intersectionEnd.Roads[intersectionEnd.Roads.WrapIndex(roadIdx + 1)]
                                                                    : GetRoadToRight(road, intersectionEnd);
                RoadData rightRoadSide = null;
                int rightRoadRailCount = -1;
                RoadSide rightRoadSideId = RoadSide.Invalid;

                if (rightRoad != null)
                    GetNextRoadInfo(RailType.Tram, rightRoad, intersectionEnd.Id, out rightRoadSide, out rightRoadRailCount, out rightRoadSideId);

                Road forwardRoad = (intersectionEnd.Roads.Count == 4) ? intersectionEnd.Roads[intersectionEnd.Roads.WrapIndex(roadIdx - 2)]
                                                                      : GetRoadAhead(road, intersectionEnd);
                RoadData forwardRoadSide = null;
                int forwardRoadRailCount = -1;
                RoadSide forwardRoadSideId = RoadSide.Invalid;

                if (forwardRoad != null)
                    GetNextRoadInfo(RailType.Tram, forwardRoad, intersectionEnd.Id, out forwardRoadSide, out forwardRoadRailCount, out forwardRoadSideId);

                // check if the same road got referenced (e.g. if this is a circular road)
                if ((leftRoad != null && leftRoad == forwardRoad) || (rightRoad != null && rightRoad == forwardRoad))
                {
                    // if so, fix this up so it's a turn / forward if possible
                    if (leftRoad != null && leftRoad == forwardRoad)
                    {
                        leftRoad = null;
                    }
                    if (rightRoad != null && rightRoad == forwardRoad)
                    {
                        forwardRoad = null;
                    }
                }

                // check if we can go any direction
                bool canTurnLeft = leftRoad != null && (leftRoadSide.AiTypeFlags & AmbientTypeFlags.Vehicles) > 0 && leftRoadRailCount > 0 && leftRoad.Id != sourceRoad.RoadInstance.Id;
                bool canTurnRight = rightRoad != null && (rightRoadSide.AiTypeFlags & AmbientTypeFlags.Vehicles) > 0 && rightRoadRailCount > 0 && rightRoad.Id != sourceRoad.RoadInstance.Id;
                bool canGoStraight = forwardRoad != null && (forwardRoadSide.AiTypeFlags & AmbientTypeFlags.Vehicles) > 0 && forwardRoadRailCount > 0 && forwardRoad.Id != sourceRoad.RoadInstance.Id;

                // Debug.Log($"DetermineNextCableCarRoad canTurnLeft {canTurnLeft} canTurnRight {canTurnRight} canGoStraight {canGoStraight}");
                // Debug.Log($"DetermineNextCableCarRoad leftRoad {(leftRoad == null ? "null" : leftRoad.Id.ToString())} rightRoad {(rightRoad == null ? "null" : rightRoad.Id.ToString())} forwardRoad {(forwardRoad == null ? "null" : forwardRoad.Id.ToString())}");

                // can't go anywhere!
                if (!canGoStraight && !canTurnLeft && !canTurnRight)
                {
                    return null;
                }

                // cable cars will first try to go straight, then right, then left
                if (canGoStraight) // straight
                {
                    return new RoadPositioningInfo
                    {
                        RoadInstance = Roads[forwardRoad.Id],
                        RailIndex = Mathf.Clamp(sourceRoad.RailIndex, 0, forwardRoadRailCount - 1),
                        SideOfRoad = forwardRoadSideId,
                        Relation = 0
                    };
                }
                if (canTurnRight) // right or straight 
                {
                    return new RoadPositioningInfo
                    {
                        RoadInstance = Roads[rightRoad.Id],
                        RailIndex = rightRoadRailCount - 1,
                        SideOfRoad = rightRoadSideId,
                        Relation = 1
                    };
                }
                if (canTurnLeft) // left or straight
                {
                    return new RoadPositioningInfo
                    {
                        RoadInstance = Roads[leftRoad.Id],
                        RailIndex = 0,
                        SideOfRoad = leftRoadSideId,
                        Relation = -1
                    };
                }
            }
            else if (intersectionEnd.Roads.Count == 2)
            {
                // try pass through
                Road forwardRoad = intersectionEnd.Roads[intersectionEnd.Roads.WrapIndex(roadIdx + 1)];
                RoadData forwardRoadSide = null;
                int forwardRoadRailCount = -1;
                RoadSide forwardRoadSideId = RoadSide.Invalid;

                GetNextRoadInfo(RailType.Tram, forwardRoad, intersectionEnd.Id, out forwardRoadSide, out forwardRoadRailCount, out forwardRoadSideId);

                bool canGoStraight = (forwardRoadSide.AiTypeFlags & AmbientTypeFlags.Vehicles) > 0 && forwardRoadRailCount > 0 && forwardRoad.Id != sourceRoad.RoadInstance.Id;

                // Debug.Log($"DetermineNextCableCarRoad canGoStraight {canGoStraight}");
                // Debug.Log($"DetermineNextCableCarRoad forwardRoad {(forwardRoad == null ? "null" : forwardRoad.Id.ToString())}");

                if (!canGoStraight)
                {
                    return null;
                }


                return new RoadPositioningInfo
                {
                    RoadInstance = Roads[forwardRoad.Id],
                    RailIndex = Mathf.Clamp(sourceRoad.RailIndex, 0, forwardRoadSide.GetRailCount(RailType.Tram) - 1),
                    SideOfRoad = forwardRoadSideId,
                    Relation = 0
                };
            }

            Debug.LogError($"DetermineNextCableCarRoad failed from {road.Id}, could not choose from {intersectionEnd.Roads.Count} choices");
            return null;
        }

        public RoadPositioningInfo? DetermineNextCableCarRoad(AIEntity entity)
        {
            return DetermineNextCableCarRoad(entity.RoadInfo);
        }

        public Road GetRoadWithinAngle(float angMin, float angMax, Road refRoad, Intersection refIntersection)
        {
            if (refRoad.LeftEndData.IntersectionID != refIntersection.Id && refRoad.RightEndData.IntersectionID != refIntersection.Id)
            {
                Debug.LogError($"GetRoadWithinAngle: refRoad {refRoad.Id} does not connect to refIntersection {refIntersection.Id}");
                return null;
            }

            var intersectionEnd = refIntersection;
            var intersectionIndexInList = (refRoad.LeftEndData.IntersectionID == refIntersection.Id) ? refRoad.LeftEndData.IntersectionRoadIndex : refRoad.RightEndData.IntersectionRoadIndex;
            int roadIdx = intersectionIndexInList < 32 ? intersectionIndexInList : intersectionEnd.Roads.IndexOf(refRoad);

            if (roadIdx < 0)
            {
                Debug.LogError($"GetRoadWithinAngle: refRoad {refRoad.Id} seemingly connects to refIntersection {refIntersection.Id}, but it can't be found in the roads reference table?");
                return null;
            }

            var angles = refIntersection.RoadAngles[roadIdx];
            int validRoadCount = angles.Count(x => x > angMin && x < angMax);

            int roadChoice = (validRoadCount > 1) ? UnityEngine.Random.Range(0, validRoadCount) : 0;
            int roadChoiceCur = 0;
            for (int i = 0; i < angles.Count; i++)
            {
                float ang = angles[i];
                var road = intersectionEnd.Roads[i];
                if (ang > angMin && ang < angMax)
                {
                    if (roadChoiceCur == roadChoice)
                        return road;
                    roadChoiceCur++;
                }
            }

            return null;
        }

        public Road GetRoadToRight(Road refRoad, Intersection refIntersection)
        {
            return GetRoadWithinAngle(30f, 175f, refRoad, refIntersection);
        }

        public Road GetRoadAhead(Road refRoad, Intersection refIntersection)
        {
            return GetRoadWithinAngle(-30f, 30f, refRoad, refIntersection);
        }

        public Road GetRoadToLeft(Road refRoad, Intersection refIntersection)
        {
            return GetRoadWithinAngle(-175f, -30f, refRoad, refIntersection);
        }

        // pathfinding stuff
        public List<Tuple<int, int>> DetermineCableCarPaths()
        {
            var pathIntersections = new List<Tuple<int, int>>();
            HashSet<int> visitedSrcDstIntersections = new HashSet<int>();

            foreach (var intersectionInstance in Intersections)
            {
                var intersection = intersectionInstance.Intersection;

                // if we've already determined this to be a start/end
                if (visitedSrcDstIntersections.Contains(intersection.Id))
                    continue;

                // find out of this is a cable car source intersection
                int sources = 0;
                Road lastSource = null;

                foreach (var road in intersection.Roads)
                {
                    if (road.LeftData.GetRailCount(RailType.Tram) > 0 || road.RightData.GetRailCount(RailType.Tram) > 0)
                    {
                        sources++;
                        lastSource = road;
                    }
                }

                // source intersection if we only have one source
                if (sources != 1)
                    continue;

                // pathfind until we hit the next intersection!
                RoadSide pathfindSide = lastSource.RightEndData.IntersectionID == intersection.Id ? RoadSide.Right
                                                                                                  : RoadSide.Left;

                RoadPositioningInfo sourceInfo = new RoadPositioningInfo { RoadInstance = Roads[lastSource.Id],
                                                                           RailIndex = 0,
                                                                           SideOfRoad = pathfindSide };
                RoadPositioningInfo? lastPositioningInfo = null;

                while (true)
                {
                    var positionInfo = DetermineNextCableCarRoad(lastPositioningInfo != null ? lastPositioningInfo.Value : sourceInfo);
                    if (positionInfo != null)
                    {
                        lastPositioningInfo = positionInfo;
                        if (lastPositioningInfo.Value.RoadInstance.Id == sourceInfo.RoadInstance.Id)
                        {
                            break;
                        }
                    }
                    else if (positionInfo == null)
                    {
                        break;
                    }
                }

                // check if an oopsie woopsie happened
                if (lastPositioningInfo != null && lastPositioningInfo.Value.RoadInstance.Id == lastSource.Id)
                {
                    Debug.LogError($"ERROR: Cable car path beginning at {lastSource.Id} is an infinite loop!");
                    continue;
                }

                // we have a start and an end!
                int intersectionEndId;
                if (lastPositioningInfo == null) // this cable car path is one road long
                {
                    intersectionEndId = lastSource.RightEndData.IntersectionID == intersection.Id ? lastSource.LeftEndData.IntersectionID : lastSource.RightEndData.IntersectionID;
                }
                else
                {
                    intersectionEndId = lastPositioningInfo.Value.SideOfRoad == RoadSide.Right ? lastPositioningInfo.Value.RoadInstance.Road.LeftEndData.IntersectionID
                                                                                               : lastPositioningInfo.Value.RoadInstance.Road.RightEndData.IntersectionID;
                }

                // add to our list and hashmap
                visitedSrcDstIntersections.Add(intersectionEndId);
                visitedSrcDstIntersections.Add(intersection.Id);
                pathIntersections.Add(new Tuple<int, int>(intersection.Id, intersectionEndId));
            }

            return pathIntersections;
        }


        public void Reset()
        {
            // basically setcullindex with a set seed
        }

        public void SetTrafficDensity(float density)
        {
            int numCars = Mathf.FloorToInt(Mathf.Clamp01(density) * TrafficCarPool.Length);
            activeTrafficCarCount = numCars;
            for (int i = activeTrafficCarCount; i < TrafficCarPool.Length; i++)
            {
                TrafficCarPool[i].RemoveFromCurrentRoad();
            }
        }

        public void SetPedestrianDensitfy(float density)
        {
            int numPeds = Mathf.FloorToInt(Mathf.Clamp01(density) * PedestrianPool.Length);
            activePedCount = numPeds;
            for (int i = activePedCount; i < PedestrianPool.Length; i++)
            {
                PedestrianPool[i].RemoveFromCurrentRoad();
            }
        }

        private void InitPedPool(int size, string[] modelNames)
        {
            var city = SDLCity.Instance;
            if (city == null)
                return;

            // pedpool arg
            var sizeArg = ArgParser.Get("pedpool");
            if (sizeArg != null && sizeArg.Parameters.Count > 0)
            {
                int.TryParse(sizeArg.Parameters[0], out size);
            }
            PedestrianPool = new AIPedestrian[size];

            // instantiate
            if (modelNames == null || modelNames.Length == 0)
            {
                Debug.LogError($"Empty pedestrian model array, not initializing any pedestrians!");
            }

            for (int i = 0; i < size; i++)
            {
                int modelIndex = modelNames.WrapIndex(i);
                var pedInstance = new GameObject(modelNames[modelIndex]);
                pedInstance.SetActive(false);
                pedInstance.transform.position = new Vector3(0, -9999f, 0); // spawn in the void

                // add to pool
                var pedestrian = new AIPedestrian(this);
                PedestrianPool[i] = pedestrian;
            }
        }

        private void InitTrafficPool(int size, Dictionary<string, float> trafficTypesAndDensity)
        {
            // This is crap, move the AIMap to this class instead
            var city = SDLCity.Instance;
            if (city == null)
                return;

            TrafficCarPool = new AITrafficCar[size];

            var trafficTypes = trafficTypesAndDensity;
            var orderedTrafficTypes = trafficTypes.OrderBy((arg) => arg.Value);

            // now init the pool
            for (int i = 0; i < size; i++)
            {
                float spawnVal = UnityEngine.Random.value;
                string spawnType = null;

                foreach (var trafficType in orderedTrafficTypes)
                {
                    if (spawnVal > trafficType.Value)
                        continue;
                    spawnType = trafficType.Key;
                    break;
                }

                if (string.IsNullOrEmpty(spawnType))
                {
                    Debug.LogError($"No spawn candidate for value {spawnVal}. There's now a NULL entry in the traffic pool!!");
                    continue;
                }

                // spawn it
                var trafficCar = new AITrafficCar(this, spawnType);
                TrafficCarPool[i] = trafficCar;
            }
        }

        private void InitTrafficLightSet(IntersectionInstance ints)
        {
            var set = new TrafficLightSet();
            ints.IntersectionLightSet = set;
        }

        private void InitControlDevices(string singleTrafLitModel = "sp_traflitsingle_f", string dualTrafLitModel = "sp_traflitdual_f")
        {
            // check if light models exist
            /*
            bool singleLightModelExists = AssetManager.Exists("geometry", $"{singleTrafLitModel}.pkg");
            bool dualLightModelExists = AssetManager.Exists("geometry", $"{dualTrafLitModel}.pkg");
            if (singleLightModelExists && !dualLightModelExists)
            {
                Debug.Log("Cannot find dual traffic light model. Falling back to single traffic light model.");
                dualTrafLitModel = singleTrafLitModel;
            }
            else if (dualLightModelExists && !singleLightModelExists)
            {
                Debug.Log("Cannot find single traffic light model. Falling back to dual traffic light model.");
                singleTrafLitModel = dualTrafLitModel;
            }
            else if (!dualLightModelExists && !singleLightModelExists)
            {
                Debug.LogError($"Cannot find any of the traffic light models listed in the AIMAP ({singleTrafLitModel}, {dualTrafLitModel})!! Traffic may be completely broken.");
                return;
            }

            trafLights[0] = BangerCache.GetShell(singleTrafLitModel).gameObject;
            trafLights[0].AddComponent<TrafficLight>().Init();

            if (singleTrafLitModel == dualTrafLitModel)
            {
                trafLights[1] = trafLights[0];
            }
            else
            {
                trafLights[1] = BangerCache.GetShell(dualTrafLitModel).gameObject;
                trafLights[1].AddComponent<TrafficLight>().Init();
            }

            // hide templates
            foreach (var trafLight in trafLights)
            {
                trafLight.SetActive(false);
            }
            */

            // create control devices
            foreach (var ints in Intersections)
            {
                // create control devices array
                int roadCount = ints.Intersection.Roads.Count;
                ints.ControlDevices = new TrafficControlDevice[roadCount];

                // assign
                for (int i = 0; i < roadCount; i++)
                {
                    var rd = ints.Intersection.Roads[i];
                    var rdSide = rd.LeftEndData.IntersectionID == ints.Id ? rd.LeftData : rd.RightData;
                    var rdEnd = rd.LeftEndData.IntersectionID == ints.Id ? rd.LeftEndData : rd.RightEndData;

                    switch (rdEnd.VehRule)
                    {
                        case VehicleRule.AlwaysStop:
                            ints.ControlDevices[i] = new AlwaysStopDevice(ints);
                            break;
                        case VehicleRule.NeverStop:
                            ints.ControlDevices[i] = new NeverStopDevice(ints);
                            break;
                        case VehicleRule.StopSign:
                            ints.ControlDevices[i] = new StopSignDevice(ints);
                            break;
                        case VehicleRule.TrafficLight:
                            if (ints.IntersectionLightSet == null)
                                InitTrafficLightSet(ints);

                            // set control device
                            var device = new TrafficLightDevice(ints);
                            ints.ControlDevices[i] = device;
                            ints.IntersectionLightSet.Lights.Add(device);
                            break;
                    }
                }
            }

            // init traffic light sets
            foreach (var ints in Intersections)
            {
                if (ints.IntersectionLightSet != null)
                    ints.IntersectionLightSet.Init();
            }
        }

        private void InitCableCarLine(int start, int end)
        {
            // TODO
            /*
            // get  intersections
            var startIntersection = networkData.Intersections[start];
            var endIntersection = networkData.Intersections[end];

            // find out what road, and what side we should be on
            var startRoad = startIntersection.Roads.First(x => (x.RightEndData.IntersectionID == start || x.LeftEndData.IntersectionID == start)
                                                            && (x.RightData.GetRailCount(RailType.Tram) > 0 || x.LeftData.GetRailCount(RailType.Tram) > 0));
            var endRoad = endIntersection.Roads.First(x => (x.RightEndData.IntersectionID == end || x.LeftEndData.IntersectionID == end)
                                                            && (x.RightData.GetRailCount(RailType.Tram) > 0 || x.LeftData.GetRailCount(RailType.Tram) > 0));

            // create our cable cars 
            var cableCarOne = AssetManager.MM2.LoadVehicleModel("va_cablecar_f");
            cableCarOne.SetRandomVariant();

            var cableCarTwo = cableCarOne.InstantiateModelInstance();

            // try and place cable car one
            int startRoadSide = -1;
            if (startRoad.LeftEndData.IntersectionID == start)
            {
                startRoadSide = 0;
            }
            else if (startRoad.RightEndData.IntersectionID == start)
            {
                startRoadSide = 0;
            }

            if (startRoadSide < 0)
            {
                Debug.Log($"Could not place cable car at start of line {start}->{end}.");
                Destroy(cableCarOne);
            }
            else
            {
                var aiCablecarOne = cableCarOne.AddComponent<AICableCar>();
                aiCablecarOne.Init("va_cablecar_f");
                aiCablecarOne.SetRoad(new RoadPositioningInfo { RoadInstance = startRoad, RailIndex = 0, SideOfRoad = startRoadSide });
                aiCablecarOne.PositionAlongPath(0f); // position cablecar away from world origin
            }

            // try and place cable car two
            int endRoadSide = -1;
            if (endRoad.LeftEndData.IntersectionID == end)
            {
                endRoadSide = 0;
            }
            else if (endRoad.RightEndData.IntersectionID == end)
            {
                endRoadSide = 0;
            }

            if (endRoadSide < 0)
            {
                Debug.Log($"Could not place cable car at end of line {start}->{end}.");
                Destroy(cableCarTwo);
            }
            else
            {
                var aiCablecarTwo = cableCarTwo.AddComponent<AICableCar>();
                aiCablecarTwo.Init("va_cablecar_f");
                aiCablecarTwo.SetRoad(new RoadPositioningInfo { RoadInstance = endRoad, RailIndex = 0, SideOfRoad = endRoadSide });
                aiCablecarTwo.PositionAlongPath(0f); // position cablecar away from world origin
            }
            */
        }

        public void Init(SDLCity level, AIMap aimap, MMWeather weather, string name)
        {
            this.level = level;

            // load network data
            string baiPath = AssetManager.CombinePath("city", $"{name}.bai");
            if (AssetManager.Exists(baiPath))
            {
                using (var stream = AssetManager.Open("city", $"{name}.bai"))
                {
                    networkData = new AINetworkData();
                    using (var reader = new BinaryReader(stream))
                    {
                        networkData.ReadBinary(reader);
                    }
                }
            }

            // Create road and intersection instances
            intersections.Clear();
            foreach(var intersectionData in networkData.Intersections)
            {
                intersections.Add(new IntersectionInstance(intersectionData));
            }

            roads.Clear();
            foreach(var roadData in networkData.Roads)
            {
                roads.Add(new RoadInstance(roadData));
            }

            // create map dicts
            RoomRoadMap.Clear();
            RoomIntersectionMap.Clear();
            IntersectionPosMap.Clear();

            // map shortcuts
            /* foreach (var cut in Shortcuts)
            {
                Intersections[cut.StartIntersection.Id].Shortcuts.Add(cut);
            }*/

            // map intersections
            foreach (var intersectionInstance in Intersections)
            {
                var ints = intersectionInstance.Intersection;

                // pos map
                IntersectionPosMap[ints.Center] = ints.Id;

                // room map
                if (ints.Room >= 0)
                    RoomIntersectionMap[ints.Room] = ints.Id;
            }

            // map roads to rooms
            foreach (var roadInstance in Roads)
            {
                var road = roadInstance.Road;
                foreach (var roomID in road.RoomRefs)
                {
                    List<int> roadMap;
                    if (!RoomRoadMap.TryGetValue(roomID, out roadMap))
                    {
                        roadMap = new List<int>();
                        RoomRoadMap[roomID] = roadMap;
                    }
                    roadMap.Add(road.Id);
                }
            }

            // init traffic pool
            InitTrafficPool(100, aimap.TrafficTypesAndDensity);

            // init ped pool
            var pedNames = (weather == MMWeather.Raining) ? aimap.BadWeatherPedModels : aimap.GoodWeatherPedModels;
            InitPedPool(aimap.PedestrianPoolSize, pedNames.ToArray());

            // init cable cars
            var cableCarPaths = DetermineCableCarPaths();
            Debug.Log($"Cable Car Paths:{cableCarPaths.Count}");
            foreach (var cableCarPath in cableCarPaths)
            {
                Debug.Log($"Start: {cableCarPath.Item1} End: {cableCarPath.Item2}");
                InitCableCarLine(cableCarPath.Item1, cableCarPath.Item2);
            }

            InitControlDevices();
        }

        public Vector3 GetRandomSpawn(int randomFactor)
        {
            var oldState = UnityEngine.Random.state;
            UnityEngine.Random.InitState(int.MaxValue);

            Vector3 spawn = Vector3.zero;

            int intersectionIdx = (UnityEngine.Random.Range(0, networkData.Intersections.Count) * (1 + randomFactor)) % networkData.Intersections.Count;
            bool foundValidIntersection = false;
            int intersectionFindAttempts = 0;

            while (!foundValidIntersection && intersectionFindAttempts < 512)
            {
                var intersection = networkData.Intersections[intersectionIdx];
                bool isIntersectionValid = true;
                foreach (var road in intersection.Roads)
                {
                    if ((road.Flags & PathFlags.Alleyway) > 0 || (road.Flags & PathFlags.Freeway) > 0)
                    {
                        isIntersectionValid = false;
                    }
                }
                foundValidIntersection = isIntersectionValid;
                if (isIntersectionValid)
                    spawn = intersection.Center;

                intersectionIdx = UnityEngine.Random.Range(0, networkData.Intersections.Count);
            }

            UnityEngine.Random.state = oldState;
            return spawn;
        }

        public Vector3 GetRandomSpawn()
        {
            return GetRandomSpawn(0);
        }

        public void SetCullRoom(int index)
        {
            this.activeCullingRoom = index;
        }

        public Intersection GetNearestIntersection(Vector3 point)
        {
            return GetNearestIntersection(new Vector2(point.x, point.z));
        }

        public Intersection GetNearestIntersection(Vector2 point)
        {
            float dist = float.MaxValue;
            Intersection last = null;

            foreach (var ints in networkData.Intersections)
            {
                float d = (new Vector2(ints.Center.x, ints.Center.z) - point).sqrMagnitude;
                if (d < dist)
                {
                    dist = d;
                    last = ints;
                }
            }

            return last;
        }


        private void Update()
        {
            // cull traffic
            if (activeCullingRoom > 0)
            {
                RepositionTraffic();
                RepositionPedestrians();
            }

            // update our entities
            // pools can contain null entries (see InitTrafficPool), and one exception here stops everything below
            if (TrafficCarPool != null)
                foreach (var trafficCar in TrafficCarPool)
                    trafficCar?.Update();
            if (PedestrianPool != null)
                foreach (var pedestrian in PedestrianPool)
                    pedestrian?.Update();
            foreach (var proxy in VehicleProxies)
                proxy.Update();

            // update active roads and intersections
            // todo: use culling data and only update active
            foreach (var road in roads)
            {
                if(road.Entities.Count != 0)
                    road.Update();
            }
            foreach (var intersection in intersections)
            {
                intersection.Update();
            }
        }

        private void OnDrawGizmos()
        {
            if (!drawEntityGizmos) return;

            if (TrafficCarPool != null)
                foreach (var car in TrafficCarPool)
                    DrawEntityGizmo(car, trafficGizmoColor);

            if (PedestrianPool != null)
                foreach (var ped in PedestrianPool)
                    DrawEntityGizmo(ped, pedestrianGizmoColor);

            foreach (var proxy in VehicleProxies)
                DrawEntityGizmo(proxy, proxyGizmoColor);
        }

        private void OnDrawGizmosSelected()
        {
            OnDrawGizmos();
        }

        private static bool IsValidRotation(Quaternion q)
        {
            float lengthSq = q.x * q.x + q.y * q.y + q.z * q.z + q.w * q.w;
            return !float.IsNaN(lengthSq) && lengthSq > 1e-6f;
        }

        private static bool IsValidPosition(Vector3 v)
        {
            return !float.IsNaN(v.x) && !float.IsNaN(v.y) && !float.IsNaN(v.z);
        }

        private void DrawEntityGizmo(AIEntity entity, Color color)
        {
            if (entity == null) return;
            if (entity.RoomID == 0) return;

            Vector3 position = entity.Position;
            Quaternion rotation = entity.Rotation;

            // Unplaced or broken entity, nothing meaningful to draw.
            if (!IsValidPosition(position) || !IsValidRotation(rotation)) return;

            // TRS wants a unit quaternion; normalize in case of drift.
            rotation = Quaternion.Normalize(rotation);

            float left = entity.LeftSideDistance;
            float right = entity.RightSideDistance;
            float front = entity.FrontBumperDistance;
            float rear = entity.RearBumperDistance;

            Vector3 size = new Vector3(right - left, 2f, front - rear);
            Vector3 localCenter = new Vector3((right + left) * 0.5f, 1f, (front + rear) * 0.5f);

            Matrix4x4 prevMatrix = Gizmos.matrix;
            Gizmos.matrix = Matrix4x4.TRS(position, rotation, Vector3.one);

            Gizmos.color = color;
            Gizmos.DrawCube(localCenter, size);
            Gizmos.color = new Color(color.r, color.g, color.b, 1f);
            Gizmos.DrawWireCube(localCenter, size);

            Gizmos.color = forwardGizmoColor;
            Vector3 nose = new Vector3(0f, size.y * 0.5f, front);
            Gizmos.DrawLine(nose, nose + Vector3.forward * Mathf.Max(0.5f, entity.Speed));

            Gizmos.matrix = prevMatrix;

#if UNITY_EDITOR
            if (entity.RoadInfo.RoadInstance != null)
            {
                UnityEditor.Handles.Label(position + Vector3.up * 2.5f,
                    $"Room {entity.RoomID}\n{entity.Speed:F1} m/s\n{entity.RoadInfo.RoadInstance.Id} Rail {entity.RoadInfo.RailIndex} Side {entity.RoadInfo.SideOfRoad}");
            }
            else
            {
                UnityEditor.Handles.Label(position + Vector3.up * 2.5f,
                $"Room {entity.RoomID}\n{entity.Speed:F1} m/s");
            }
#endif
        }
    }
}