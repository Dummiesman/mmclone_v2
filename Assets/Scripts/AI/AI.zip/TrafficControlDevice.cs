using MM2.AI;
using System.Collections.Generic;
using UnityEngine;

public abstract class TrafficControlDevice
{
    public readonly IntersectionInstance Intersection;

    public abstract bool CanEnterIntersection(AIEntity entity);
    public virtual void Update() { }

    private TrafficControlDevice() { }
    public TrafficControlDevice(IntersectionInstance intersection)
    {
        Intersection = intersection;
    }
}

public class TrafficLightDevice : TrafficControlDevice
{
    private const float longTimer = 5.0f;
    private const float shortTimer = 1.5f;
    private float currentTimer = float.MaxValue;

    public bool TimerEnabled = true;

    private TrafficLightState _currentState;
    private TrafficLightState nextState;
    public TrafficLightState State
    {
        get
        {
            return _currentState;
        }
        set
        {
            _currentState = value;
            SetNextState();
        }
    }

    public TrafficLightDevice(IntersectionInstance intersection) : base(intersection)
    {
    }

    public override void Update()
    {
        if (!TimerEnabled)
            return;

        currentTimer -= Time.deltaTime;
        if (currentTimer <= 0f)
            State = nextState; // setter schedules the following state and timer
    }

    void SetNextState()
    {
        if (State == TrafficLightState.Red)
        {
            // Red lasts as long as the cross traffic's green + yellow, otherwise both directions overlap.
            currentTimer = longTimer + shortTimer;
            nextState = TrafficLightState.Green;
        }
        else if (State == TrafficLightState.Yellow)
        {
            currentTimer = shortTimer;
            nextState = TrafficLightState.Red;
        }
        else if (State == TrafficLightState.Green)
        {
            currentTimer = longTimer;
            nextState = TrafficLightState.Yellow;
        }
    }

    public override bool CanEnterIntersection(AIEntity entity)
    {
        if (entity.RailType == RailType.Pedestrian)
        {
            // use the pedestrian light state
            return State != TrafficLightState.Red;
        }

        // other entities
        if (Intersection.IntersectionLightSet.IsFourWay && entity.NextRoadInfo.RoadInstance != null)
        {
            for (int i = 0; i < Intersection.EntitiesInIntersection.Count; i++)
            {
                var isEntity = Intersection.EntitiesInIntersection[i];
                if (isEntity.NextRoadInfo.RoadInstance == null || (isEntity.NextRoadInfo.RoadInstance.Id 
                                                                   != entity.RoadInfo.RoadInstance.Id))
                    continue;

                //someone is crossing straight, we must wait for them to turn left
                if (isEntity.NextRoadInfo.Relation == 0 && entity.NextRoadInfo.Relation < 0)
                {
                    return false;
                }
            }
        }

        // no four way logic
        return State != TrafficLightState.Red;
    }
}

public class StopSignDevice : TrafficControlDevice
{
    public bool InDepthCheck = false;

    public StopSignDevice(IntersectionInstance intersection) : base(intersection)
    {
    }

    private const float MinWaitTime = 1f;
    private const float StoppedSpeed = 0.1f;

    private readonly Dictionary<AIEntity, float> waitTimes = new Dictionary<AIEntity, float>();
    private readonly List<AIEntity> waitKeys = new List<AIEntity>();

    public override bool CanEnterIntersection(AIEntity entity)
    {
        if (!waitTimes.TryGetValue(entity, out float waitTime))
        {
            waitTimes[entity] = 0f;
        }
       
        if (InDepthCheck)
        {
            foreach (var cd in Intersection.ControlDevices)
            {
                if (cd == this)
                    continue;
                if (cd.CanEnterIntersection(entity))
                    return false;
            }
        }

        //enforce a min wait time
        if (waitTime >= MinWaitTime && Intersection.NumVehiclesInIntersection == 0)
        {
            waitTimes.Remove(entity);
            return true;
        }
        else
        {
            return false;
        }
    }

    public override void Update()
    {
        base.Update();

        // Don't write to the dictionary while enumerating it, that throws.
        waitKeys.Clear();
        waitKeys.AddRange(waitTimes.Keys);
        foreach (var entity in waitKeys)
        {
            // Entity moved on, was repositioned, or is now heading somewhere else.
            if (entity.CurrentDestIntersection != Intersection)
            {
                waitTimes.Remove(entity);
                continue;
            }

            // Only count time actually spent stopped.
            if (entity.Speed <= StoppedSpeed)
                waitTimes[entity] += Time.deltaTime;
        }
    }
}

public class NeverStopDevice : TrafficControlDevice
{
    public NeverStopDevice(IntersectionInstance intersection) : base(intersection)
    {
    }

    public override bool CanEnterIntersection(AIEntity entity)
    {
        return true;
    }
}

public class AlwaysStopDevice : TrafficControlDevice
{
    public AlwaysStopDevice(IntersectionInstance intersection) : base(intersection)
    {
    }

    public override bool CanEnterIntersection(AIEntity entity)
    {
        return false;
    }
}