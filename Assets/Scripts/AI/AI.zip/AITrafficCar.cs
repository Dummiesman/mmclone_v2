using UnityEngine;

namespace MM2.AI
{
    public class AITrafficCar : AIRailEntity
    {
        private AIVehicleData vehicleData;

        public int RoomID => roomId;
        private int roomId;

        public override float FrontBumperDistance
        {
            get => vehicleData.CG.z + (vehicleData.Size.z * 0.5f);
        }

        public override float RearBumperDistance
        {
            get => vehicleData.CG.z - (vehicleData.Size.z * 0.5f);
        }

        public override float LeftSideDistance
        {
            get => vehicleData.CG.x - (vehicleData.Size.x * 0.5f);
        }

        public override float RightSideDistance
        {
            get => vehicleData.CG.x + (vehicleData.Size.x * 0.5f);
        }

        private float lastSpeed = 0f;

        private float wheelXAngle = 0f;
        private float wheelYAngle = 0f;

        public bool TailLightsActive => tailLightsActive;
        private bool tailLightsActive;

        // curve computing
        private const int CurveLengthSamples = 16;
        protected HermiteCurve intersectionCurve = new HermiteCurve();
        protected HermiteEvaluator intersectionCurveEvaluator;
        protected float intersectionCurveLength = 0f;

        // intersection state
        private bool inIntersection = false;
        private IntersectionInstance currentIntersection;
        private float intersectionDistance = 0f;

        public bool InIntersection => inIntersection;

        public override void GetCorners(out Vector3 frontLeft, out Vector3 frontRight, out Vector3 rearRight)
        {
            if (vehicleData != null)
            {
                var data = vehicleData;
                frontLeft  = Position + Rotation * data.WheelPositions[0];
                frontRight = Position + Rotation * data.WheelPositions[1];
                rearRight  = Position + Rotation * data.WheelPositions[3];
            }
            else
            {
                base.GetCorners(out frontLeft, out frontRight, out rearRight);
            }
        }

        void UpdateTaillights()
        {
            //set last speed and tail lights active
            if (Speed < lastSpeed)
            {
                tailLightsActive = true;
            }
            else if (Speed > lastSpeed)
            {
                tailLightsActive = false;
            }
        }

        private void ComputeIntersectionCurve()
        {
            intersectionCurveEvaluator = null;
            intersectionCurveLength = 0f;

            if (NextRoadInfo.RoadInstance == null || RoadInfo.RoadInstance == null)
                return;

            int lastSection = RoadInfo.RoadInstance.Road.NumSections - 1;

            //get road end and next road start
            var roadEnd = RoadInfo.RoadData.GetVertex(RailType, RoadInfo.RailIndex, lastSection);
            var roadEndDir = (roadEnd - RoadInfo.RoadData.GetVertex(RailType, RoadInfo.RailIndex, lastSection - 1)).normalized;

            var nxtRoadData = NextRoadInfo.RoadData;
            var nxtRoadStart = nxtRoadData.GetVertex(RailType, NextRoadInfo.RailIndex, 0);
            var nxtRoadStartDir = (nxtRoadData.GetVertex(RailType, NextRoadInfo.RailIndex, 1) - nxtRoadStart).normalized;

            //flatten direction vectors
            nxtRoadStartDir.y = 0f;
            roadEndDir.y = 0f;

            //create a curve
            intersectionCurve.Points.Clear();
            intersectionCurve.Points.Add(new HermitePoint { Position = roadEnd, Tangent = roadEndDir * 1.05f });
            intersectionCurve.Points.Add(new HermitePoint { Position = nxtRoadStart, Tangent = nxtRoadStartDir * 1.05f });

            intersectionCurveEvaluator = new HermiteEvaluator(intersectionCurve.Points);

            //compute curve length by sampling, so turns take as long as they look
            float length = 0f;
            Vector3 prev = intersectionCurveEvaluator.Evaluate(0f);
            for (int i = 1; i <= CurveLengthSamples; i++)
            {
                Vector3 p = intersectionCurveEvaluator.Evaluate(i / (float)CurveLengthSamples);
                length += Vector3.Distance(prev, p);
                prev = p;
            }
            intersectionCurveLength = length;
        }

        private void EnterIntersection(float overshoot)
        {
            // Read this before RoadInfo is cleared, it's derived from it.
            currentIntersection = CurrentDestIntersection;

            RemoveFromCurrentRoad();
            RoadInfo = RoadPositioningInfo.Null;

            currentIntersection?.Enter(this);
            inIntersection = true;
            intersectionDistance = overshoot;
        }

        private void LeaveIntersectionState()
        {
            currentIntersection?.Leave(this);
            currentIntersection = null;
            inIntersection = false;
        }

        private void ExitIntersection(float overshoot)
        {
            var next = NextRoadInfo;
            LeaveIntersectionState();

            // Progress before SetRoad: Lane.Insert sorts on it.
            NormalizedPathProgress = Mathf.Clamp01(overshoot / next.RoadInstance.Road.Length);
            SetRoad(next);
            PositionAlongPath(NormalizedPathProgress);
        }

        private void UpdateIntersection()
        {
            // Don't drive into whatever is sitting at the start of the lane we're joining.
            float maxTravel = float.PositiveInfinity;
            var nextLane = NextRoadInfo.RoadInstance?.GetLane(NextRoadInfo.SideOfRoad, RailType, NextRoadInfo.RailIndex);
            var blocker = nextLane?.NextAhead(0f, this);
            if (blocker != null)
            {
                float remaining = intersectionCurveLength - intersectionDistance;
                float theirRear = blocker.CurrentPathDistance + blocker.RearBumperDistance;
                maxTravel = remaining + theirRear - FrontBumperDistance - StopGapMeters;
            }

            float targetSpeed = GetTargetSpeed(maxTravel);
            if (targetSpeed < speed)
                speed = targetSpeed;
            else
                speed = Mathf.MoveTowards(speed, targetSpeed, accelerationRate * Time.deltaTime);

            intersectionDistance += Mathf.Min(speed * Time.deltaTime, Mathf.Max(0f, maxTravel));

            if (intersectionCurveEvaluator == null || intersectionDistance >= intersectionCurveLength)
            {
                ExitIntersection(Mathf.Max(0f, intersectionDistance - intersectionCurveLength));
                return;
            }

            const float LookStep = 0.01f;
            float t = intersectionDistance / intersectionCurveLength;

            Vector3 pos = intersectionCurveEvaluator.Evaluate(t);
            Vector3 dir = t + LookStep <= 1f
                ? intersectionCurveEvaluator.Evaluate(t + LookStep) - pos
                : pos - intersectionCurveEvaluator.Evaluate(t - LookStep);

            position = pos;
            if (dir.sqrMagnitude > 1e-6f)
                rotation = Quaternion.LookRotation(dir, Vector3.up);

            UpdateRoom();
        }

        private void RefreshNextRoad()
        {
            var next = network.DetermineNextRoad(this);

            // Only accept a destination we can actually drive onto, otherwise we'd wait at the line forever.
            if (next.HasValue && next.Value.RoadInstance != null &&
                next.Value.RoadInstance.GetLane(next.Value.SideOfRoad, RailType, next.Value.RailIndex) != null)
            {
                NextRoadInfo = next.Value;
                ComputeIntersectionCurve();
            }
            else
            {
                NullNextRoad();
                intersectionCurveEvaluator = null;
            }
        }

        public override void SetRoad(RoadPositioningInfo newRoadInfo)
        {
            // Repositioned mid-crossing: drop out of the intersection cleanly.
            if (inIntersection)
                LeaveIntersectionState();

            base.SetRoad(newRoadInfo);
            speedLimit = newRoadInfo.RoadInstance.Road.SpeedLimit;
            RefreshNextRoad();
        }

        private void UpdateRoom()
        {
            int newRoom = network.Level.FindRoomIdWithWarpsCheckMiss(Position, roomId);
            if (newRoom != roomId)
                roomId = newRoom;
        }

        public override void Update()
        {
            if (inIntersection)
            {
                UpdateIntersection();
            }
            else
            {
                // Not placed yet.
                if (RoadInfo.RoadInstance == null)
                    return;

                // Dead end last time we looked, try again.
                if (NextRoadInfo.RoadInstance == null)
                    RefreshNextRoad();

                base.Update();

                float roadLength = RoadInfo.RoadInstance.Road.Length;
                if (NextRoadInfo.RoadInstance != null && CurrentPathDistance >= roadLength)
                {
                    EnterIntersection(CurrentPathDistance - roadLength);
                }
            }

            UpdateTaillights();
            lastSpeed = Speed;
        }

        public AITrafficCar(AINetwork network, string typeName) : base(network)
        {
            var dataMgr = network.VehicleDataManager;
            int dataIndex = dataMgr.AddVehicleDataEntry(typeName);
            this.vehicleData = dataMgr.GetEntry(dataIndex);

            // Without these, DetermineNextRoad rejects every road and we never get a next road.
            RailType = RailType.Vehicle;
            AmbientTypeFlagMask = AmbientTypeFlags.Vehicles;
            NullNextRoad();
        }
    }
}
