using System;

namespace MM2.AI
{
    public enum TrafficLightState
    {
        Red,
        Yellow,
        Green
    }

    public enum PedLightState
    {
        Walk,
        NoWalk
    }

    public enum RoadSide
    {
        Invalid = -1,
        Left = 0,
        Right = 1
    }

    [Flags]
    public enum PathFlags
    {
        Divided = 1,
        Alleyway = 2,
        Freeway = 4,
        Flat = 8
    }

    [Flags]
    public enum AmbientTypeFlags
    {
        None = 0,
        Vehicles = 1,
        Pedestrians = 2
    }

    public enum VehicleRule
    {
        StopSign,
        TrafficLight,
        AlwaysStop,
        NeverStop
    }

    public enum RailType
    {
        Vehicle,
        Pedestrian,
        Tram,
        Subway
    }
}