using UnityEngine;

namespace MM2.AI
{
    public class PoliceData
    {
        public string VehicleBasename;
        public Vector3 StartPosition;
        public float StartRotation;

        public int Unknown1;
        public int Unknown2;

        public float OpponentChaseChance;
        public float MaxChaseDistance;
    }
}