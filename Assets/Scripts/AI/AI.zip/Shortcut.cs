﻿using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace MM2.AI
{
    public class ShortcutData
    {
        public ushort NumLanes;
        public ushort NumTrams;
        public ushort NumTrains;
        public ushort NumSidewalks;
        public AmbientTypeFlags AmbientType;

        public List<Vector3> TramVertices = new List<Vector3>();
        public List<Vector3> TrainVertices = new List<Vector3>();

        public List<Vector3> OuterVertices = new List<Vector3>();
        public List<Vector3> InnerVertices = new List<Vector3>();

        public static ShortcutData ReadBinary(BinaryReader reader, Shortcut parent)
        {
            var sd = new ShortcutData();

            sd.NumLanes = reader.ReadUInt16();
            sd.NumTrams = reader.ReadUInt16();
            sd.NumTrains = reader.ReadUInt16();
            sd.NumSidewalks = reader.ReadUInt16();
            sd.AmbientType = (AmbientTypeFlags)reader.ReadUInt16();

            //skip for now
            reader.BaseStream.Seek((parent.NumSections * 4) * (sd.NumSidewalks + sd.NumLanes), SeekOrigin.Current);
            reader.BaseStream.Seek((4) * (sd.NumSidewalks + sd.NumLanes), SeekOrigin.Current);
            reader.BaseStream.Seek(40, SeekOrigin.Current);
            reader.BaseStream.Seek((parent.NumSections * 12) * (sd.NumSidewalks + sd.NumLanes), SeekOrigin.Current);

            if(sd.NumTrams > 0)
            {
                for(int i=0; i < parent.NumSections; i++)
                {
                    sd.TramVertices.Add(reader.ReadVector3Flipped());
                }
            }

            if (sd.NumTrains > 0)
            {
                for (int i = 0; i < parent.NumSections; i++)
                {
                    sd.TrainVertices.Add(reader.ReadVector3Flipped());
                }
            }

            //outer and inner
            for (int i = 0; i < parent.NumSections; i++)
            {
                sd.OuterVertices.Add(reader.ReadVector3Flipped());
            }

            for (int i = 0; i < parent.NumSections; i++)
            {
                sd.InnerVertices.Add(reader.ReadVector3Flipped());
            }

            //return
            return sd;
        }
    }

    public class Shortcut
    {
        public ushort Id;
        public ushort NumSections;
        public PathFlags Flags;

        public List<int> RoomRefs = new List<int>();
        public float HalfWidth;
        public float SpeedBase;

        public ShortcutData Left;
        public ShortcutData Right;

        public HermiteCurve SectionCenterCurve = new HermiteCurve();
        public List<float> CenterDistances = new List<float>();
        public List<Vector3> XOrientation = new List<Vector3>();
        public List<Vector3> YOrientation = new List<Vector3>();
        public List<Vector3> ZOrientation = new List<Vector3>();

        public ShortcutIntersection EndIntersection;
        public ShortcutIntersection StartIntersection;

        public static Shortcut ReadBinary(BinaryReader reader)
        {
            var sc = new Shortcut();

            sc.Id = reader.ReadUInt16();
            sc.NumSections = reader.ReadUInt16();
            sc.Flags = (PathFlags)reader.ReadInt16();

            int roomCount = reader.ReadUInt16();
            for (int i = 0; i < roomCount; i++)
                sc.RoomRefs.Add(Mathf.Abs(reader.ReadInt16()));

            sc.HalfWidth = reader.ReadSingle();
            sc.SpeedBase = reader.ReadSingle();

            sc.Left = ShortcutData.ReadBinary(reader, sc);
            sc.Right = ShortcutData.ReadBinary(reader, sc);

            for (int i = 0; i < sc.NumSections; i++)
                sc.CenterDistances.Add(reader.ReadSingle());
            for (int i = 0; i < sc.NumSections; i++)
                sc.SectionCenterCurve.Points.Add(new HermitePoint() { Position = reader.ReadVector3Flipped() });
            for (int i = 0; i < sc.NumSections; i++)
                sc.XOrientation.Add(reader.ReadVector3Flipped());
            for (int i = 0; i < sc.NumSections; i++)
                sc.YOrientation.Add(reader.ReadVector3Flipped());
            for (int i = 0; i < sc.NumSections; i++)
                sc.ZOrientation.Add(reader.ReadVector3Flipped());
            for (int i = 0; i < sc.NumSections; i++)
            {
                var pt = sc.SectionCenterCurve.Points[i];
                pt.Tangent = reader.ReadVector3Flipped();
                sc.SectionCenterCurve.Points[i] = pt;
            }

            sc.EndIntersection = ShortcutIntersection.ReadBinary(reader);
            sc.StartIntersection = ShortcutIntersection.ReadBinary(reader);

            return sc;
        }
    }
}