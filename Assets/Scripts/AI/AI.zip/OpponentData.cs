﻿using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

namespace MM2.AI
{
    public class OpponentData
    {
        public string VehicleBasename;
        public string OpponentFile;
        public float SpeedMultiplier = 1f;
        public bool UnknownFlag;
        public float CornerAwareness = 50f;
        public float CornerAwarenessSpeed = 0.5f;

        public bool AvoidTraffic;
        public bool AvoidProps;
        public bool AvoidPlayers;
        public bool AvoidOpponents;
        public bool BadPathfinding;

        public float BrakingThreshold = 1f;

        public static OpponentData Parse(string oppData)
        {
            string[] oppSplit = oppData.Clean().Split(' ');
            var opp = new OpponentData
            {
                VehicleBasename = oppSplit[0],
                OpponentFile = oppSplit[1],

                SpeedMultiplier = (oppSplit.Length > 2) ? FastFloatParser.Parse(oppSplit[2]) : 1.0f,
                UnknownFlag = (oppSplit.Length > 3) ? oppSplit[3] != "0" : false,
                CornerAwareness = (oppSplit.Length > 4) ? FastFloatParser.Parse(oppSplit[4]) : 50f,
                CornerAwarenessSpeed = (oppSplit.Length > 5) ? FastFloatParser.Parse(oppSplit[5]) : 0.5f,

                AvoidTraffic = (oppSplit.Length > 6) ? oppSplit[6] != "0" : true,
                AvoidProps = (oppSplit.Length > 7) ? oppSplit[7] != "0" : false,
                AvoidPlayers = (oppSplit.Length > 8) ? oppSplit[8] != "0" : false,
                AvoidOpponents = (oppSplit.Length > 9) ? oppSplit[9] != "0" : false,
                BadPathfinding = (oppSplit.Length > 10) ? oppSplit[10] != "0" : false,

                BrakingThreshold = (oppSplit.Length > 11) ? FastFloatParser.Parse(oppSplit[11]) : 1.0f
            };
            return opp;
        }
    }
}