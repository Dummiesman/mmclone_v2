﻿using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace MM2.AI
{
    public class RoadEnd
    {
        public int IntersectionID;
        public VehicleRule VehRule;
        public int IntersectionRoadIndex;
        public Vector3 TrafficLightOrigin;
        public Vector3 TrafficLightOrientation;

        public void WriteBinary(BinaryWriter writer)
        {
            if(IntersectionID < 0)
            {
                writer.Write(0xCDCDCDCD);
            }
            else
            {
                writer.Write(IntersectionID);
            }

            writer.Write((ushort)0xcdcd);
            writer.Write((int)VehRule);
            writer.Write(IntersectionRoadIndex);
            writer.WriteVector3Flipped(TrafficLightOrigin);
            writer.WriteVector3Flipped(TrafficLightOrientation);
        }

        public static RoadEnd ReadBinary(BinaryReader reader)
        {
            var end = new RoadEnd();

            //read data
            end.IntersectionID = reader.ReadInt32();
            if(end.IntersectionID == unchecked((int)0xCDCDCDCD))
            {
                end.IntersectionID = -1;
            }

            reader.BaseStream.Seek(2, SeekOrigin.Current); //unknown value
            end.VehRule = (VehicleRule)reader.ReadInt32();
            end.IntersectionRoadIndex = reader.ReadInt32();
            end.TrafficLightOrigin = reader.ReadVector3Flipped();
            end.TrafficLightOrientation = reader.ReadVector3Flipped();

            return end;
        }
    }

    public class RoadData
    {
        public int numLanes;
        public int numTrams;
        public int numTrains;
        public bool hasSidewalk;

        /// <summary>
        /// This appears to be
        /// NUMLANES count: Center distances
        /// SIDEWALK count: Sidewalk center distances
        /// ONE COUNT: halfWidth repeated, but negative?
        /// NUMLANES count * 2: Center distances, repeated twice for each lane?
        /// ONE COUNT: halfWidth repeated?
        /// </summary>
        public float[] UnknownFloats;

        public float[] UnknownFloats2;
        public float[,] LaneDistances;
        public float[] OuterEdgeDistances;

        public List<HermiteCurve> VehicleCurves;
        public List<HermiteCurve> TramCurves;
        public List<HermiteCurve> TrainCurves;

        public Vector3[] SidewalkVertices;
        public Vector3[] SidewalkInnerVertices;
        public Vector3[] SidewalkOuterVertices;
        public AmbientTypeFlags AiTypeFlags;

        public Vector3 GetVertex(RailType type, int lane, int sectionIndex)
        {
            switch (type)
            {
                case RailType.Pedestrian:
                    return GetSidewalkVertex(sectionIndex);
                case RailType.Subway:
                    return GetTrainVertex(lane, sectionIndex);
                case RailType.Vehicle:
                    return GetVehicleVertex(lane, sectionIndex);
                case RailType.Tram:
                    return GetTramVertex(lane, sectionIndex);
            }
            return Vector3.zero;
        }

        public int GetTotalRailCount()
        {
            return (hasSidewalk ? 1 : 0) + numTrains + numTrams + numLanes;
        }

        public int GetRailCount(RailType type)
        {
            switch (type)
            {
                case RailType.Pedestrian:
                    return hasSidewalk ? 1 : 0;
                case RailType.Subway:
                    return numTrains;
                case RailType.Tram:
                    return numTrams;
                case RailType.Vehicle:
                    return numLanes;
            }
            return 0;
        }

        public Vector3 GetVehicleVertex(int lane, int sectionIndex)
        {
            return VehicleCurves[lane].Points[sectionIndex].Position;
        }

        public void SetVehicleVertex(int lane, int sectionIndex, Vector3 vertex)
        {
            var pt = VehicleCurves[lane].Points[sectionIndex];
            pt.Position = vertex;
            VehicleCurves[lane].Points[sectionIndex] = pt;
        }

        public Vector3 GetTramVertex(int lane, int sectionIndex)
        {
            return TramCurves[lane].Points[sectionIndex].Position;
        }

        public void SetTramVertex(int lane, int sectionIndex, Vector3 vertex)
        {
            var pt = TramCurves[lane].Points[sectionIndex];
            pt.Position = vertex;
            TramCurves[lane].Points[sectionIndex] = pt;
        }

        public Vector3 GetTrainVertex(int lane, int sectionIndex)
        {
            return TrainCurves[lane].Points[sectionIndex].Position;
        }

        public void SetTrainVertex(int lane, int sectionIndex, Vector3 vertex)
        {
            var pt = TrainCurves[lane].Points[sectionIndex];
            pt.Position = vertex;
            TrainCurves[lane].Points[sectionIndex] = pt;
        }

        public Vector3 GetSidewalkVertex(int sectionIndex)
        {
            return SidewalkVertices[sectionIndex];
        }

        public void SetSidewalkVertex(int sectionIndex, Vector3 vertex)
        {
            SidewalkVertices[sectionIndex] = vertex;
        }

        /*public bool IsSidewalkReversed(Road parentRoad)
        {
            var ainet = SDLCity.Instance.AINetwork;
            var endIntersectionA = ainet.Intersections[parentRoad.RightEndData.IntersectionID];
            var endIntersectionB = ainet.Intersections[parentRoad.LeftEndData.IntersectionID];

            if(this == parentRoad.RightData)
            {
                float distToEnd = (endIntersectionA.Center - SidewalkVertices[0]).sqrMagnitude;
                float distToStart= (endIntersectionB.Center - SidewalkVertices[0]).sqrMagnitude;
                return distToEnd < distToStart;
            }
            else
            {
                float distToEnd = (endIntersectionB.Center - SidewalkVertices[0]).sqrMagnitude;
                float distToStart= (endIntersectionA.Center - SidewalkVertices[0]).sqrMagnitude;
                return distToEnd < distToStart;
            }
        }*/

        public void WriteBinary(BinaryWriter writer, int numSections)
        {
            writer.Write((ushort)numLanes);
            writer.Write((ushort)numTrams);
            writer.Write((ushort)numTrains);
            writer.Write((ushort)(hasSidewalk ? 1 : 0));

            //reverse to do bitflags
            ushort typeFlags = (ushort)AiTypeFlags;
            typeFlags = (ushort)(3 - typeFlags);

            writer.Write(typeFlags);

            //the fun part
            for (int i = 0; i < numLanes; i++)
            {
                for (int j = 0; j < numSections; j++)
                {
                    writer.Write(LaneDistances[i, j]);
                }
            }

            for (int i = 0; i < OuterEdgeDistances.Length; i++)
                writer.Write(OuterEdgeDistances[i]);

            //unknown
            for (int i = 0; i < UnknownFloats.Length; i++)
                writer.Write(UnknownFloats[i]);

            //unknown
            for (int i = 0; i < UnknownFloats2.Length; i++)
                writer.Write(UnknownFloats2[i]);

            //write vehicle verts
            for (int i = 0; i < numLanes; i++)
            {
                for (int j = 0; j < numSections; j++)
                    writer.WriteVector3Flipped(VehicleCurves[i].Points[j].Position);
            }

            //write sidewalk center verts
            for (int i = 0; i < numSections; i++)
                writer.WriteVector3Flipped(SidewalkVertices[i]);

            //write tram vertices
            for (int i = 0; i < numTrams; i++)
            {
                for (int j = 0; j < numSections; j++)
                    writer.WriteVector3Flipped(TramCurves[i].Points[j].Position);
            }

            //write train vertices
            for (int i = 0; i < numTrains; i++)
            {
                for (int j = 0; j < numSections; j++)
                    writer.WriteVector3Flipped(TrainCurves[i].Points[j].Position);
            }

            //write sidewalk inner verts
            for (int i = 0; i < numSections; i++)
                writer.WriteVector3Flipped(SidewalkInnerVertices[i]);

            //write sidewalk outer verts
            for (int i = 0; i < numSections; i++)
                writer.WriteVector3Flipped(SidewalkOuterVertices[i]);
        }

        public static RoadData ReadBinary(BinaryReader reader, Road parent)
        {
            var data = new RoadData();

            //read header
            data.numLanes = reader.ReadUInt16();
            data.numTrams = reader.ReadUInt16();
            data.numTrains = reader.ReadUInt16();
            data.hasSidewalk = (reader.ReadUInt16() > 0);

            //swap 3 and 0 to do bitflags
            int ambientType = reader.ReadUInt16();
            ambientType = 3 - ambientType;

            //init data
            data.UnknownFloats = new float[10];
            data.UnknownFloats2 = new float[data.numLanes];
            data.LaneDistances = new float[data.numLanes, parent.NumSections];
            data.OuterEdgeDistances = new float[parent.NumSections + (data.hasSidewalk ? 1 : 0)];
            data.VehicleCurves = new List<HermiteCurve>();
            data.TramCurves = new List<HermiteCurve>();
            data.TrainCurves = new List<HermiteCurve>();
            data.SidewalkVertices = new Vector3[parent.NumSections];
            data.SidewalkInnerVertices = new Vector3[parent.NumSections];
            data.SidewalkOuterVertices = new Vector3[parent.NumSections];
            data.AiTypeFlags = (AmbientTypeFlags)ambientType;

            //read data
            //read lane distances
            for (int i = 0; i < data.numLanes; i++)
            {
                for (int j = 0; j < parent.NumSections; j++)
                    data.LaneDistances[i, j] = reader.ReadSingle();
            }

            //read outer edge distances
            for (int i = 0; i < data.OuterEdgeDistances.Length; i++)
                data.OuterEdgeDistances[i] = reader.ReadSingle();

            //read unk data
            for (int i = 0; i < data.UnknownFloats.Length; i++)
            {
                data.UnknownFloats[i] = reader.ReadSingle();
            }

            //unknown
            for (int i = 0; i < data.numLanes; i++)
            {
                data.UnknownFloats2[i] = reader.ReadSingle();
            }

            //read lane vertices
            for (int i = 0; i < data.numLanes; i++)
            {
                List<HermitePoint> lanePoints = new List<HermitePoint>();
                for (int j = 0; j < parent.NumSections; j++)
                    lanePoints.Add(new HermitePoint() { Position = reader.ReadVector3Flipped() });
                data.VehicleCurves.Add(new HermiteCurve(lanePoints));
            }

            //read sidewalk center verts
            for (int i = 0; i < parent.NumSections; i++)
                data.SidewalkVertices[i] = reader.ReadVector3Flipped();

            //read tram vertices
            for (int i = 0; i < data.numTrams; i++)
            {
                List<HermitePoint> lanePoints = new List<HermitePoint>();
                for (int j = 0; j < parent.NumSections; j++)
                    lanePoints.Add(new HermitePoint() { Position = reader.ReadVector3Flipped() });
                data.TramCurves.Add(new HermiteCurve(lanePoints));
            }

            //read train vertices
            for (int i = 0; i < data.numTrains; i++)
            {
                List<HermitePoint> lanePoints = new List<HermitePoint>();
                for (int j = 0; j < parent.NumSections; j++)
                    lanePoints.Add(new HermitePoint() { Position = reader.ReadVector3Flipped() });
                data.TrainCurves.Add(new HermiteCurve(lanePoints));
            }

            //read sidewalk inner verts
            for (int i = 0; i < parent.NumSections; i++)
                data.SidewalkInnerVertices[i] = reader.ReadVector3Flipped();

            //read sidewalk outer verts
            for (int i = 0; i < parent.NumSections; i++)
                data.SidewalkOuterVertices[i] = reader.ReadVector3Flipped();

            return data;
        }

        public void CopyTangents(Road road, bool mirror)
        {
            void CopyTo(IEnumerable<HermiteCurve> curves)
            {
                foreach (var curve in curves)
                {
                    for (int i = 0; i < road.SectionCenterCurve.Points.Count; i++)
                    {
                        int index = mirror
                            ? road.SectionCenterCurve.Points.Count - 1 - i
                            : i;

                        var point = curve.Points[i];
                        point.Tangent = road.SectionCenterCurve.Points[index].Tangent;

                        if (mirror)
                            point.Tangent *= -1;

                        curve.Points[i] = point;
                    }
                }
            }

            CopyTo(VehicleCurves);
            CopyTo(TramCurves);
            CopyTo(TrainCurves);
        }
    }

    public class Road
    {
        private int numSections;
        public int NumSections
        {
            get { return numSections; }
        }

        public float Length =>this.NumSections > 0 ? SectionCenterDistances[numSections - 1] : 0f;

        public int TotalLanes => (LeftData.numLanes + RightData.numLanes);
        public int HighestLaneCount => Mathf.Max(LeftData.numLanes, RightData.numLanes);
        public int LowestLaneCount => Mathf.Min(LeftData.numLanes, RightData.numLanes);

        public int Id;
        public PathFlags Flags;
        public int[] RoomRefs;
        public float HalfWidth;
        public float SpeedLimit;

        public RoadData LeftData;
        public RoadData RightData;

        public float[] SectionCenterDistances;
        public HermiteCurve SectionCenterCurve;
        public Vector3[] SectionXOrientations;
        public Vector3[] SectionYOrientations;
        public Vector3[] SectionZOrientations;

        public RoadEnd RightEndData;
        public RoadEnd LeftEndData;

        /// <summary>
        /// Distance along the road at a side-local section index. SectionCenterDistances is stored in
        /// right-side order; left side data runs the other way (see GetSidedInfoAtPoint), so mirror it.
        /// </summary>
        public float GetSectionDistance(RoadSide side, int sectionIndex)
        {
            if (side == RoadSide.Left)
                return Length - SectionCenterDistances[numSections - 1 - sectionIndex];
            return SectionCenterDistances[sectionIndex];
        }

        public Vector3 GetEndVertex()
        {
            return SectionCenterCurve.Points[numSections - 1].Position;
        }

        public Vector3 GetStartVertex()
        {
            return SectionCenterCurve.Points[0].Position;
        }

        public void GetInfoAtPoint(Vector3 point, out int railIndex, out int sectionIndex, out RoadSide side)
        {
            var testPointF = new Vector2(point.x, point.z);

            //defaults
            railIndex = -1;
            sectionIndex = -1;
            side = RoadSide.Invalid;

            for (int i = NumSections - 1; i >= 0; i--)
            {
                var sectionCtr = new Vector2(SectionCenterCurve.Points[i].Position.x, SectionCenterCurve.Points[i].Position.z);
                Vector2 dirToPoint = new Vector2(testPointF.x - sectionCtr.x, testPointF.y - sectionCtr.y);

                var sectionForward = SectionZOrientations[i].ToVec2XZ();
                var sectionXOri = SectionXOrientations[i].ToVec2XZ();
                var sectionZOri = SectionZOrientations[i].ToVec2XZ();

                //within front/back?
                float forwardDot = -Vector2.Dot(dirToPoint, sectionZOri);
                if (forwardDot >= 0)
                {
                    //last section, and we're ahead. not on this road
                    if (i == numSections - 1)
                        break;

                    //check if we're within left/right boundaries
                    float sideDot = Vector2.Dot(dirToPoint, sectionXOri);
                    float sideDotAbs = Mathf.Abs(sideDot);

                    if (sideDot >= -HalfWidth && sideDot <= HalfWidth)
                    {
                        //set section
                        sectionIndex = i;

                        //set side
                        if (IsOnewayRoad())
                        {
                            if (RightData.numLanes > 0)
                            {
                                side = RoadSide.Right;
                            }
                            else if(LeftData.numLanes > 0)
                            {
                                side = RoadSide.Left;
                            }
                        }
                        else
                        {
                            side = (sideDot > 0) ? RoadSide.Left : RoadSide.Right;
                        }


                        //find lane
                        var data = side > 0 ? RightData : LeftData;
                        for (int j = 0; j < data.numLanes ; j++)
                        {
                            int floatIdx = (data.numLanes + 1) + (j * 2);
                            //int floatIdx = 1 + (j * 2);
                            if (floatIdx >= data.UnknownFloats.Length)
                                break;

                            if (IsOnewayRoad() && false)
                            {
                                if ((sideDotAbs + HalfWidth) < data.UnknownFloats[floatIdx])
                                {
                                    railIndex = j;
                                    break;
                                }
                            }
                            else
                            {
                                if (sideDotAbs < data.UnknownFloats[floatIdx])
                                {
                                    railIndex = j;
                                    break;
                                }
                            }
                        }

                        //done
                        break; 
                    }
                }
            }
        }
        
        public void GetSidedInfoAtPoint(Vector3 point, out int railIndex, out int sectionIndex, out RoadSide side)
        {
            GetInfoAtPoint(point, out railIndex, out sectionIndex, out side);
            if(side == 0)
                sectionIndex = numSections - sectionIndex - 2;
        }

        /// <summary>
        /// Find out what side of the road an arbitrary point is at
        /// (will return 0 if this point is not within the road!)
        /// </summary>
        /// <returns>The point road side.</returns>
        /// <param name="point">Point.</param>
        public RoadSide GetPointRoadSide(Vector3 point)
        {
            GetInfoAtPoint(point, out int railIndex, out int sectionIndex, out var side);
            return side;
        }

        /// <summary>
        /// Find out what section this point is in
        /// </summary>
        /// <returns>The point section index.</returns>
        /// <param name="point">Point.</param>
        public int GetPointSectionIndex(Vector3 point)
        {
            GetInfoAtPoint(point, out int railIndex, out int sectionIndex, out var side);
            return sectionIndex;
        }

        /// <summary>
        /// Find out what section this point is in
        /// </summary>
        /// <returns>The point section index.</returns>
        /// <param name="point">Point.</param>
        public int GetPointSectionIndexSided(Vector3 point)
        {
            GetSidedInfoAtPoint(point, out int railIndex, out int sectionIndex, out var side);
            return sectionIndex;
        }

        public bool IsPointOnRoad(Vector3 point)
        {
            return GetPointSectionIndex(point) >= 0;
        }

        public Vector3 GetCenter()
        {
            //uneven sections are already perfect
            if (numSections % 2 > 0)
            {
                return SectionCenterCurve.Points[Mathf.CeilToInt((float)numSections / 2f)].Position;
            }

            //else, interpolate
            if (numSections == 2)
                return Vector3.Lerp(SectionCenterCurve.Points[0].Position, SectionCenterCurve.Points[1].Position, 0.5f);
            if (numSections == 1)
                return SectionCenterCurve.Points[0].Position;

            Vector3 section1 = SectionCenterCurve.Points[numSections / 2].Position;
            Vector3 section2 = SectionCenterCurve.Points[(numSections / 2) + 1].Position;
            return Vector3.Lerp(section1, section2, 0.5f);
        }

        public void CalculateHalfWidth()
        {
            float width = 0f;

            //loop through sections and find the largest width
            for(int i=0; i < numSections; i++)
            {
                var sectionCtr =  SectionCenterCurve.Points[i].Position;
                var sectionCtrF = new Vector2(sectionCtr.x, sectionCtr.z);

                var sectionXO = SectionXOrientations[i];
                var sectionXOF = new Vector2(sectionXO.x, sectionXO.z);

                var testPoint = LeftData.SidewalkOuterVertices[i];
                var testPointF = new Vector2(testPoint.x, testPoint.z);

                float xSum = testPointF.x - sectionCtrF.x;
                float zSum = testPointF.y - sectionCtrF.y;
                Vector2 xzSum = new Vector2(xSum, zSum);

                float xzDot = Mathf.Abs(Vector2.Dot(xzSum, sectionXOF));

                if(xzDot > width)
                {
                    width = xzDot;
                }

            }

            this.HalfWidth = width;
        }

   
        public float CalculateLaneOuterBoundaryDist(int side, int lane)
        {
            float width = 0f;
            lane++; //add one since this is outer boundary

            //loop through sections and find the largest width
            for (int i = 0; i < numSections; i++)
            {
                var sectionCtr = SectionCenterCurve.Points[i].Position;
                var sectionCtrF = new Vector2(sectionCtr.x, sectionCtr.z);

                var sectionXO = SectionXOrientations[i];
                var sectionXOF = new Vector2(sectionXO.x, sectionXO.z);

                Vector3 testPoint;
                if(side == 1 && lane == RightData.numLanes)
                {
                    testPoint = RightData.GetSidewalkVertex(i);
                }else if(side == 0 && lane == LeftData.numLanes)
                {
                    testPoint = LeftData.GetSidewalkVertex(i);
                }
                else
                {
                    testPoint = (side == 1) ? RightData.GetVehicleVertex(lane, i) : LeftData.GetVehicleVertex(lane, i);
                }
                var testPointF = new Vector2(testPoint.x, testPoint.z);

                float xSum = testPointF.x - sectionCtrF.x;
                float zSum = testPointF.y - sectionCtrF.y;
                Vector2 xzSum = new Vector2(xSum, zSum);

                float xzDot = Mathf.Abs(Vector2.Dot(xzSum, sectionXOF));

                if (xzDot > width)
                {
                    width = xzDot;
                }

            }

            return width;
        }

        public bool IsOnewayRoad()
        {
            int ll = LeftData.numLanes;
            int rl = RightData.numLanes;

            //can't determine
            if (ll == 0 && rl == 0) //both zero
            {
                return false;
            }else if(ll == 0 || rl == 0) //one side has no lanes
            {
                return true;
            }
            else //both sides have lanes
            {
                return false;
            }
        }

        public void WriteBinary(BinaryWriter writer)
        {
            writer.Write((ushort)Id);
            writer.Write((ushort)numSections);

            writer.Write((short)Flags);

            writer.Write((ushort)RoomRefs.Length);
            for (int i = 0; i < RoomRefs.Length; i++)
                writer.Write((ushort)(RoomRefs[i]));

            writer.Write(HalfWidth);
            writer.Write(SpeedLimit);

            LeftData.WriteBinary(writer, numSections);
            RightData.WriteBinary(writer, numSections);

            //write section data
            for (int i = 0; i < numSections; i++)
                writer.Write(SectionCenterDistances[i]);
            for (int i = 0; i < numSections; i++)
                writer.WriteVector3Flipped(SectionCenterCurve.Points[i].Position);
            for (int i = 0; i < numSections; i++)
                writer.WriteVector3Flipped(SectionXOrientations[i]);
            for (int i = 0; i < numSections; i++)
                writer.WriteVector3Flipped(SectionYOrientations[i]);
            for (int i = 0; i < numSections; i++)
                writer.WriteVector3Flipped(SectionZOrientations[i]);
            for (int i = 0; i < numSections; i++)
                writer.WriteVector3Flipped(SectionCenterCurve.Points[i].Tangent);

            //write RoadEnd's
            LeftEndData.WriteBinary(writer);
            RightEndData.WriteBinary(writer);
        }

        public static Road ReadBinary(BinaryReader reader)
        {
            var road = new Road();

            //read road header
            road.Id = reader.ReadUInt16();
            road.numSections = reader.ReadUInt16();

            road.Flags = (PathFlags)reader.ReadInt16(); 

            road.RoomRefs = new int[reader.ReadUInt16()]; //init room list
            for (int i = 0; i < road.RoomRefs.Length; i++)
                road.RoomRefs[i] = reader.ReadUInt16();

            road.HalfWidth = reader.ReadSingle();
            road.SpeedLimit = reader.ReadSingle();

            //read road data
            road.LeftData = RoadData.ReadBinary(reader, road);
            road.RightData = RoadData.ReadBinary(reader, road);

            //init section data
            road.SectionCenterCurve = new HermiteCurve();
            road.SectionCenterDistances = new float[road.numSections];
            road.SectionXOrientations = new Vector3[road.numSections];
            road.SectionYOrientations = new Vector3[road.numSections];
            road.SectionZOrientations = new Vector3[road.numSections];

            //read section data
            for (int i = 0; i < road.numSections; i++)
                road.SectionCenterDistances[i] = reader.ReadSingle();
            for (int i = 0; i < road.numSections; i++)
                road.SectionCenterCurve.Points.Add(new HermitePoint() { Position = reader.ReadVector3Flipped() });
            for (int i = 0; i < road.numSections; i++)
                road.SectionXOrientations[i] = reader.ReadVector3Flipped();
            for (int i = 0; i < road.numSections; i++)
                road.SectionYOrientations[i] = reader.ReadVector3Flipped();
            for (int i = 0; i < road.numSections; i++)
                road.SectionZOrientations[i] = reader.ReadVector3Flipped();
            for (int i = 0; i < road.numSections; i++)
            {
                var point = road.SectionCenterCurve.Points[i];
                point.Tangent = reader.ReadVector3Flipped();
                road.SectionCenterCurve.Points[i] = point;
            }

            //set tangents
            road.LeftData.CopyTangents(road, true);
            road.RightData.CopyTangents(road, false);

            //recalculate halfwidth if zero (some mod maps)
            if (road.HalfWidth <= Mathf.Epsilon) 
                road.CalculateHalfWidth();

            
            /*if (road.LeftData.numLanes > 0)
            {
                Debug.Log($"== Road {road.Id} ===");
                float maxDeviation = 0f;
                for (int i = 0; i < road.LeftData.numLanes; i++)
                {
                    try
                    {
                        float calc = road.CalculateLaneOuterBoundaryDist(0, i);
                        maxDeviation = Mathf.Max(Mathf.Abs(road.LeftData.UnknownFloats[i] - calc), maxDeviation);
                        road.LeftData.UnknownFloats[i] = calc;
                    //Debug.Log($"Calc {calc} MM {road.LeftData.UnknownFloats[i]}");
                    }
                    catch (System.Exception e)
                    {

                    }
                }

                if(maxDeviation > 0.15)
                {
                    Debug.LogError($"Calculation deviation on rd {road.Id} (deviation={maxDeviation})");
                }
            }

            */
            /*
                //Debug.Log($"Calc {road.HalfWidth} MM {road.LeftData.UnknownFloats[road.LeftData.numLanes + road.LeftData.numLanes]}");
            }
            if (road.RightData.numLanes > 0)
            {
                Debug.Log($"== Road {road.Id} ===");
                for (int i = 0; i < road.RightData.numLanes; i++)
                {
                    try
                    {
                        float calc = road.CalculateLaneOuterBoundaryDist(0, i);
                        road.RightData.UnknownFloats[i] = calc;
                        Debug.Log($"Calc {calc} MM {road.RightData.UnknownFloats[i]}");
                    }catch(System.Exception e)
                    {

                    }
                }
                Debug.Log($"Calc {-road.HalfWidth} MM {road.RightData.UnknownFloats[road.RightData.numLanes]}");
                road.RightData.UnknownFloats[road.RightData.numLanes] = -road.HalfWidth;

                for (int i = 0; i < road.RightData.numLanes; i += 2)
                {
                    try
                    {
                        float calc = road.CalculateLaneOuterBoundaryDistHalf(0, i);
                    road.RightData.UnknownFloats[i + road.RightData.numLanes + 1] = calc;
                    Debug.Log($"Calc {calc} MM {road.RightData.UnknownFloats[i + road.RightData.numLanes + 1]}");
                    }
                    catch (System.Exception e)
                    {

                    }
                }
                //Debug.Log($"Calc {road.HalfWidth} MM {road.LeftData.UnknownFloats[road.LeftData.numLanes + road.LeftData.numLanes]}");
            }
            */

            //read RoadEnd's
        
            road.LeftEndData = RoadEnd.ReadBinary(reader);
            road.RightEndData = RoadEnd.ReadBinary(reader);

            return road;
        }
    }
}
